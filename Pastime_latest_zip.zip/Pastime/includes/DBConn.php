<?php
// ============================================================
//  Pastimes — includes/DBConn.php
//  Database Connection File
//  Pre-loved Fashion Marketplace
// ============================================================

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database configuration
$host     = "localhost";
$dbname   = "ClothingStore";
$username = "root";
$password = "";

// Try to connect with error handling
try {
    $conn = new mysqli($host, $username, $password);
    
    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    
    // Create database if not exists
    if (!$conn->query("CREATE DATABASE IF NOT EXISTS ClothingStore")) {
        throw new Exception("Failed to create database: " . $conn->error);
    }
    
    // Select the database
    if (!$conn->select_db($dbname)) {
        throw new Exception("Failed to select database: " . $conn->error);
    }
    
} catch (Exception $e) {
    die("Database Error: " . $e->getMessage() . "<br><br>
         Please make sure:
         <ul>
             <li>MySQL is running in XAMPP Control Panel</li>
             <li>Username is 'root'</li>
             <li>Password is empty (default XAMPP)</li>
             <li>MySQL is running on port 3306</li>
         </ul>
         <a href='/' style='color:#8da05f;'>← Go back</a>");
}

// ============================================
// TABLE: tblUser
// ============================================
$conn->query("
CREATE TABLE IF NOT EXISTS tblUser (
    userID     INT AUTO_INCREMENT PRIMARY KEY,
    fullName   VARCHAR(100) NOT NULL,
    email      VARCHAR(100) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,
    isVerified TINYINT(1) DEFAULT 0,
    role       ENUM('customer','seller','admin') DEFAULT 'customer',
    createdAt  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// ============================================
// TABLE: tblAdmin
// ============================================
$conn->query("
CREATE TABLE IF NOT EXISTS tblAdmin (
    adminID   INT AUTO_INCREMENT PRIMARY KEY,
    fullName  VARCHAR(100) NOT NULL,
    email     VARCHAR(100) NOT NULL UNIQUE,
    password  VARCHAR(255) NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// ============================================
// TABLE: tblClothes (Main product table)
// ============================================
$conn->query("
CREATE TABLE IF NOT EXISTS tblClothes (
    clothesID   INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    description TEXT,
    price       DECIMAL(10,2) NOT NULL,
    stock       INT DEFAULT 0,
    image       VARCHAR(100) DEFAULT 'default.jpg',
    createdAt   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// ============================================
// TABLE: tbl_Item (Alias for shop.php compatibility)
// ============================================
$conn->query("
CREATE TABLE IF NOT EXISTS tbl_Item (
    clothesID   INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    description TEXT,
    price       DECIMAL(10,2) NOT NULL,
    stock       INT DEFAULT 0,
    image       VARCHAR(100) DEFAULT 'default.jpg',
    createdAt   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// ============================================
// TABLE: tblAorder (Legacy orders)
// ============================================
$conn->query("
CREATE TABLE IF NOT EXISTS tblAorder (
    orderID   INT AUTO_INCREMENT PRIMARY KEY,
    userID    INT NOT NULL,
    clothesID INT NOT NULL,
    quantity  INT DEFAULT 1,
    orderDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userID)    REFERENCES tblUser(userID),
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID)
)");

// ============================================
// TABLE: tblCart (Database-backed cart)
// ============================================
$conn->query("
CREATE TABLE IF NOT EXISTS tblCart (
    cartID    INT AUTO_INCREMENT PRIMARY KEY,
    userID    INT NOT NULL,
    clothesID INT NOT NULL,
    quantity  INT DEFAULT 1,
    addedAt   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userID)    REFERENCES tblUser(userID),
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID)
)");

// ============================================
// TABLE: tblOrders (Master orders)
// ============================================
$conn->query("
CREATE TABLE IF NOT EXISTS tblOrders (
    orderID     INT AUTO_INCREMENT PRIMARY KEY,
    userID      INT NOT NULL,
    orderNumber VARCHAR(50) UNIQUE,
    totalAmount DECIMAL(10,2) NOT NULL,
    status      ENUM('Pending','Processing','Shipped','Delivered','Cancelled') DEFAULT 'Pending',
    orderDate   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userID) REFERENCES tblUser(userID)
)");

// ============================================
// TABLE: tblOrderItems (Individual order items)
// ============================================
$conn->query("
CREATE TABLE IF NOT EXISTS tblOrderItems (
    orderItemID INT AUTO_INCREMENT PRIMARY KEY,
    orderID     INT NOT NULL,
    clothesID   INT NOT NULL,
    quantity    INT NOT NULL,
    price       DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (orderID)   REFERENCES tblOrders(orderID),
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID)
)");

// ============================================
// TABLE: tblSellerRequests (Seller listings)
// ============================================
$conn->query("
CREATE TABLE IF NOT EXISTS tblSellerRequests (
    requestID   INT AUTO_INCREMENT PRIMARY KEY,
    userID      INT NOT NULL,
    itemName    VARCHAR(100) NOT NULL,
    description TEXT,
    itemPrice   DECIMAL(10,2) NOT NULL,
    brand       VARCHAR(50),
    image       VARCHAR(100) DEFAULT 'default.jpg',
    status      ENUM('Pending','Approved','Rejected') DEFAULT 'Pending',
    requestDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userID) REFERENCES tblUser(userID)
)");

// ============================================
// TABLE: tblCommunications (Admin-User messages)
// ============================================
$conn->query("
CREATE TABLE IF NOT EXISTS tblCommunications (
    commID     INT AUTO_INCREMENT PRIMARY KEY,
    senderID   INT,
    receiverID INT,
    message    TEXT NOT NULL,
    isRead     TINYINT(1) DEFAULT 0,
    sentDate   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// ============================================
// Insert default admin if not exists
// ============================================
$adminPass = md5("admin123");
$conn->query("INSERT IGNORE INTO tblAdmin (fullName, email, password)
              VALUES ('Administrator', 'admin@clothingstore.co.za', '$adminPass')");

// ============================================
// Insert default users if not exists
// ============================================
$pass = md5("password123");
$defaultUsers = [
    ["John Doe",      "j.doe@abc.co.za"],
    ["Jane Smith",    "j.smith@abc.co.za"],
    ["Bob Johnson",   "b.johnson@abc.co.za"],
    ["Alice Brown",   "a.brown@abc.co.za"],
    ["Charlie Davis", "c.davis@abc.co.za"],
];
foreach ($defaultUsers as $u) {
    $n = $conn->real_escape_string($u[0]);
    $e = $conn->real_escape_string($u[1]);
    $conn->query("INSERT IGNORE INTO tblUser (fullName, email, password, isVerified)
                  VALUES ('$n', '$e', '$pass', 1)");
}

// ============================================
// Insert default clothes if not exists
// ============================================
$clothes = [
    ["T-Shirt",  "Classic cotton T-Shirt",  99.99,  50, "tshirt.jpg"],
    ["Jeans",    "Slim fit denim jeans",     299.99, 30, "jeans.jpg"],
    ["Jacket",   "Genuine leather biker jacket", 599.99, 15, "jacket.jpg"],
    ["Sneakers", "Classic white sneakers",   399.99, 25, "sneakers.jpg"],
    ["Cap",      "Adjustable baseball cap",  79.99,  60, "cap.jpg"],
];
foreach ($clothes as $c) {
    $n = $conn->real_escape_string($c[0]);
    $d = $conn->real_escape_string($c[1]);
    $img = $conn->real_escape_string($c[4]);
    $conn->query("INSERT IGNORE INTO tblClothes (name, description, price, stock, image)
                  VALUES ('$n', '$d', {$c[2]}, {$c[3]}, '$img')");
    $conn->query("INSERT IGNORE INTO tbl_Item (name, description, price, stock, image)
                  VALUES ('$n', '$d', {$c[2]}, {$c[3]}, '$img')");
}

// ============================================
// FUNCTIONS for API compatibility
// ============================================

/**
 * Get a database connection (for compatibility with other files)
 */
function getDBConnection() {
    global $conn;
    return $conn;
}

/**
 * Set CORS headers for API endpoints
 */
function corsHeaders() {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');
    header('Content-Type: application/json; charset=utf-8');
    
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit();
    }
}

/**
 * Check if user is logged in
 */
function isLoggedIn() {
    return isset($_SESSION['userID']);
}

/**
 * Get current user data
 */
function getCurrentUser() {
    global $conn;
    if (!isLoggedIn()) return null;
    
    $userID = (int)$_SESSION['userID'];
    $result = $conn->query("SELECT * FROM tblUser WHERE userID = $userID");
    return $result ? $result->fetch_assoc() : null;
}

/**
 * Get cart count for current user
 */
function getCartCount() {
    global $conn;
    if (!isLoggedIn()) return 0;
    
    $userID = (int)$_SESSION['userID'];
    $result = $conn->query("SELECT SUM(quantity) as total FROM tblCart WHERE userID = $userID");
    if ($result) {
        $row = $result->fetch_assoc();
        return (int)($row['total'] ?? 0);
    }
    return 0;
}

/**
 * Add item to cart
 */
function addToCart($clothesID, $quantity = 1) {
    global $conn;
    if (!isLoggedIn()) return false;
    
    $userID = (int)$_SESSION['userID'];
    $clothesID = (int)$clothesID;
    $quantity = (int)$quantity;
    
    // Check if item already in cart
    $check = $conn->query("SELECT cartID, quantity FROM tblCart 
                          WHERE userID = $userID AND clothesID = $clothesID");
    
    if ($check && $check->num_rows > 0) {
        $row = $check->fetch_assoc();
        $newQty = $row['quantity'] + $quantity;
        return $conn->query("UPDATE tblCart SET quantity = $newQty 
                            WHERE cartID = {$row['cartID']}");
    } else {
        return $conn->query("INSERT INTO tblCart (userID, clothesID, quantity) 
                            VALUES ($userID, $clothesID, $quantity)");
    }
}

/**
 * Remove item from cart
 */
function removeFromCart($cartID) {
    global $conn;
    if (!isLoggedIn()) return false;
    
    $userID = (int)$_SESSION['userID'];
    $cartID = (int)$cartID;
    
    return $conn->query("DELETE FROM tblCart WHERE cartID = $cartID AND userID = $userID");
}

/**
 * Clear user's cart
 */
function clearCart() {
    global $conn;
    if (!isLoggedIn()) return false;
    
    $userID = (int)$_SESSION['userID'];
    return $conn->query("DELETE FROM tblCart WHERE userID = $userID");
}

/**
 * Get user's cart items
 */
function getCartItems() {
    global $conn;
    if (!isLoggedIn()) return [];
    
    $userID = (int)$_SESSION['userID'];
    $result = $conn->query("
        SELECT c.*, i.name, i.price, i.image 
        FROM tblCart c
        JOIN tbl_Item i ON c.clothesID = i.clothesID
        WHERE c.userID = $userID
    ");
    
    $items = [];
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $items[] = $row;
        }
    }
    return $items;
}
?>