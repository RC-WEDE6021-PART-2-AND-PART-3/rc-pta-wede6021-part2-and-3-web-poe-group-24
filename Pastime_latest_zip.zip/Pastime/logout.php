<?php
session_start();

// Clear all session variables
$_SESSION = array();

// Destroy the session
session_destroy();

// Redirect to splash page (not login page)
header("Location: splashPage.php");
exit();
?>