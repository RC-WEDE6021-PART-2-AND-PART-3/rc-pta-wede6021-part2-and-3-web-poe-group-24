<?php
session_start();
require_once __DIR__ . '/includes/DBConn.php';

if (!isset($_SESSION['userID'])) {
    header("Location: login.php");
    exit();
}

$userID = (int)$_SESSION['userID'];

// Get cart items with product details
$items = [];
$total = 0;
$count = 0;

$result = $conn->query("
    SELECT c.*, i.name, i.price, i.image, i.stock, i.category
    FROM tblCart c
    JOIN tbl_Item i ON c.clothesID = i.clothesID
    WHERE c.userID = $userID
");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $clothesID = $row['clothesID'];
        $items[$clothesID] = [
            'name' => $row['name'],
            'price' => $row['price'],
            'image' => $row['image'],
            'quantity' => $row['quantity'],
            'stock' => $row['stock'],
            'category' => $row['category'] ?? 'Uncategorized'
        ];
        $total += $row['price'] * $row['quantity'];
        $count += $row['quantity'];
    }
}

if (empty($items)) {
    header("Location: shop.php");
    exit();
}

// Process checkout
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['checkout'])) {
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Generate order number
        $orderNumber = 'ORD-' . date('Ymd') . '-' . strtoupper(uniqid());
        $totalAmount = $total;
        
        // Insert order
        $conn->query("
            INSERT INTO tblOrders (userID, orderNumber, totalAmount, status)
            VALUES ($userID, '$orderNumber', $totalAmount, 'Pending')
        ");
        $orderID = $conn->insert_id;
        
        // Insert order items and decrement stock
        foreach ($items as $clothesID => $item) {
            $quantity = (int)$item['quantity'];
            $price = (float)$item['price'];
            
            // Insert order item
            $conn->query("
                INSERT INTO tblOrderItems (orderID, clothesID, quantity, price)
                VALUES ($orderID, $clothesID, $quantity, $price)
            ");
            
            // Also insert into legacy tblAorder
            $conn->query("
                INSERT INTO tblAorder (userID, clothesID, quantity)
                VALUES ($userID, $clothesID, $quantity)
            ");
            
            // Decrement stock
            $conn->query("
                UPDATE tbl_Item SET stock = stock - $quantity
                WHERE clothesID = $clothesID AND stock >= $quantity
            ");
            
            if ($conn->affected_rows == 0) {
                throw new Exception("Insufficient stock for item: " . $item['name']);
            }
        }
        
        // Clear cart
        $conn->query("DELETE FROM tblCart WHERE userID = $userID");
        
        // Commit transaction
        $conn->commit();
        
        // Store order details in session
        $_SESSION['last_order'] = [
            'orderID' => $orderID,
            'orderNumber' => $orderNumber,
            'totalAmount' => $totalAmount
        ];
        
        header("Location: order_confirmation.php");
        exit();
        
    } catch (Exception $e) {
        $conn->rollback();
        $error = $e->getMessage();
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Checkout - Pastimes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,600;1,400&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: { 50: '#f4f6f0', 500: '#8da05f', 600: '#75874f' }
                    },
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'sans-serif'],
                        serif: ['Playfair Display', 'serif']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-[#f5f0e8] min-h-screen font-sans">

    <nav class="bg-white border-b border-black/5 px-8 py-4 flex justify-between items-center">
        <a href="splashPage.php" class="text-2xl font-serif text-brand-600 font-bold">Pastimes</a>
        <div class="flex items-center gap-6 text-sm font-medium text-neutral-600">
            <a href="shop.php" class="hover:text-brand-500">Continue Shopping</a>
            <a href="cart.php" class="hover:text-brand-500">View Cart</a>
            <a href="logout.php" class="text-red-500 hover:text-red-600">Logout</a>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto px-6 py-10">
        <h1 class="text-3xl font-bold text-neutral-800 tracking-tight mb-2">📋 Checkout</h1>
        <p class="text-sm text-neutral-500 mb-8">Review your order before confirming</p>

        <?php if ($error): ?>
        <div class="bg-red-100 text-red-700 p-4 rounded-xl mb-6">
            ❌ <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>

        <div class="grid md:grid-cols-3 gap-6">
            <!-- Order Summary -->
            <div class="md:col-span-2">
                <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm overflow-hidden">
                    <div class="px-6 py-4 bg-neutral-50/50 border-b border-neutral-100">
                        <h2 class="font-semibold">Order Summary</h2>
                    </div>
                    <div class="divide-y divide-neutral-100">
                        <?php foreach ($items as $clothesID => $item): ?>
                        <div class="px-6 py-4 flex items-center gap-4">
                            <img src="/Pastime/images/<?= htmlspecialchars($item['image'] ?? 'default.jpg') ?>" 
                                 alt="<?= htmlspecialchars($item['name']) ?>"
                                 class="w-16 h-16 object-cover rounded-lg"
                                 onerror="this.src='/Pastime/images/default.jpg'">
                            <div class="flex-1">
                                <h3 class="font-medium text-neutral-800"><?= htmlspecialchars($item['name']) ?></h3>
                                <p class="text-xs text-neutral-500"><?= htmlspecialchars($item['category']) ?></p>
                                <p class="text-sm text-neutral-500">Qty: <?= $item['quantity'] ?></p>
                            </div>
                            <div class="font-semibold text-brand-600">R<?= number_format($item['price'] * $item['quantity'], 2) ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Total & Checkout -->
            <div>
                <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-6 sticky top-24">
                    <h2 class="font-semibold text-lg mb-4">Order Total</h2>
                    <div class="space-y-2 text-sm">
                        <div class="flex justify-between">
                            <span class="text-neutral-500">Subtotal</span>
                            <span>R<?= number_format($total, 2) ?></span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-neutral-500">Shipping</span>
                            <span class="text-green-600">Free</span>
                        </div>
                        <div class="border-t border-neutral-200 pt-3 mt-3">
                            <div class="flex justify-between font-bold text-lg">
                                <span>Total</span>
                                <span class="text-brand-600">R<?= number_format($total, 2) ?></span>
                            </div>
                        </div>
                    </div>

                    <form method="POST" action="">
                        <button type="submit" name="checkout" value="1" 
                                class="w-full mt-6 bg-brand-500 text-white font-semibold py-3 rounded-xl hover:bg-brand-600 transition-colors">
                            ✅ Confirm Order
                        </button>
                    </form>

                    <a href="cart.php" class="block text-center text-sm text-neutral-500 mt-4 hover:text-brand-500">
                        ← Back to Cart
                    </a>
                </div>
            </div>
        </div>
    </div>

</body>
</html>