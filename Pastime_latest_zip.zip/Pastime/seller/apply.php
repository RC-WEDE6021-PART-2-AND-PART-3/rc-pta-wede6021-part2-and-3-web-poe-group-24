<?php
session_start();
require_once __DIR__ . '/../includes/DBConn.php';

if (!isset($_SESSION['userID'])) {
    header("Location: /Pastime/login.php");
    exit();
}

$userID = (int)$_SESSION['userID'];
$fullName = $_SESSION['fullName'] ?? 'User';

// Get user data
$user = $conn->query("SELECT * FROM tblUser WHERE userID = $userID")->fetch_assoc();

$message = '';
$error = '';

// Check if already a seller
if ($user['is_seller'] == 1) {
    header("Location: dashboard.php");
    exit();
}

// Handle application
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $seller_bio = $conn->real_escape_string(trim($_POST['seller_bio'] ?? ''));
    $seller_phone = $conn->real_escape_string(trim($_POST['seller_phone'] ?? ''));
    $seller_address = $conn->real_escape_string(trim($_POST['seller_address'] ?? ''));
    $seller_category = $conn->real_escape_string(trim($_POST['seller_category'] ?? ''));
    
    if (empty($seller_bio) || empty($seller_phone)) {
        $error = 'Please fill in all required fields.';
    } else {
        $conn->query("
            UPDATE tblUser SET 
                is_seller = 1,
                seller_status = 'pending',
                seller_application_date = NOW(),
                seller_bio = '$seller_bio',
                seller_phone = '$seller_phone',
                seller_address = '$seller_address'
            WHERE userID = $userID
        ");
        
        // Add seller category (if you have a seller_categories table)
        // For now, we'll store it in a simple way
        
        $message = '✅ Your seller application has been submitted! An admin will review it shortly.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Apply as Seller - Pastimes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,600;1,400&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: { 50: '#f4f6f0', 500: '#8da05f', 600: '#75874f' }
                    },
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'sans-serif'],
                        serif: ['Playfair Display', 'serif']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-[#f5f0e8] min-h-screen font-sans">

    <nav class="bg-white border-b border-black/5 px-8 py-4 flex justify-between items-center">
        <a href="/Pastime/splashPage.php" class="text-2xl font-serif text-brand-600 font-bold">Pastimes</a>
        <div class="flex items-center gap-6 text-sm font-medium text-neutral-600">
            <a href="/Pastime/shop.php" class="hover:text-brand-500">Browse</a>
            <a href="/Pastime/dashboard.php" class="hover:text-brand-500">Dashboard</a>
            <a href="/Pastime/logout.php" class="text-red-500 hover:text-red-600">Logout</a>
        </div>
    </nav>

    <div class="max-w-2xl mx-auto px-6 py-12">
        <div class="bg-white rounded-3xl border border-neutral-200/60 shadow-sm p-8">
            <h1 class="text-3xl font-bold text-neutral-800 tracking-tight mb-2">👑 Become a Seller</h1>
            <p class="text-sm text-neutral-500 mb-8">Apply to start selling your items on Pastimes</p>

            <?php if ($message): ?>
            <div class="bg-green-100 text-green-700 p-4 rounded-xl mb-6"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
            <div class="bg-red-100 text-red-700 p-4 rounded-xl mb-6">❌ <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <?php if (!$message): ?>
            <div class="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6">
                <p class="text-sm text-amber-800">📌 Before you apply:</p>
                <ul class="text-sm text-amber-700 list-disc list-inside mt-2">
                    <li>You must be a verified member</li>
                    <li>Provide accurate contact information</li>
                    <li>Your application will be reviewed by an admin</li>
                    <li>You can list up to 50 items once approved</li>
                </ul>
            </div>

            <form method="POST" action="">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-neutral-700 mb-1">Full Name</label>
                        <input type="text" value="<?= htmlspecialchars($user['fullName'] ?? '') ?>" disabled
                               class="w-full px-4 py-2 border border-neutral-200 rounded-lg bg-neutral-50">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-neutral-700 mb-1">Email</label>
                        <input type="email" value="<?= htmlspecialchars($user['email'] ?? '') ?>" disabled
                               class="w-full px-4 py-2 border border-neutral-200 rounded-lg bg-neutral-50">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-neutral-700 mb-1">Phone Number *</label>
                        <input type="tel" name="seller_phone" required
                               class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                               placeholder="+27 XX XXX XXXX">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-neutral-700 mb-1">What category of items do you sell? *</label>
                        <select name="seller_category" required
                                class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent">
                            <option value="">Select a category...</option>
                            <option value="Tops">Tops</option>
                            <option value="Bottoms">Bottoms</option>
                            <option value="Outerwear">Outerwear</option>
                            <option value="Footwear">Footwear</option>
                            <option value="Accessories">Accessories</option>
                            <option value="Mixed">Mixed/Various</option>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-neutral-700 mb-1">Address (for shipping)</label>
                        <input type="text" name="seller_address"
                               class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                               placeholder="Your business or shipping address">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-neutral-700 mb-1">Tell us about yourself *</label>
                        <textarea name="seller_bio" rows="4" required
                                  class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                                  placeholder="Why do you want to become a seller? What kind of items do you plan to sell?"></textarea>
                    </div>

                    <button type="submit" class="w-full bg-brand-500 text-white font-semibold py-3 rounded-xl hover:bg-brand-600 transition">
                        Submit Application
                    </button>
                </div>
            </form>
            <?php endif; ?>

            <div class="mt-6 text-center">
                <a href="/Pastime/dashboard.php" class="text-neutral-500 hover:text-brand-500 text-sm">← Back to Dashboard</a>
            </div>
        </div>
    </div>

</body>
</html>