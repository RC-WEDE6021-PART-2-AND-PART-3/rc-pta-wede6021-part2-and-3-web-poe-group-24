<?php
session_start();
require_once __DIR__ . '/../includes/DBConn.php';

if (!isset($_SESSION['userID'])) {
    header("Location: /Pastime/login.php");
    exit();
}

$userID = (int)$_SESSION['userID'];
$fullName = $_SESSION['fullName'] ?? 'User';

// Get user data
$user = $conn->query("SELECT * FROM tblUser WHERE userID = $userID")->fetch_assoc();

// Check if user is a seller
if ($user['is_seller'] != 1) {
    header("Location: apply.php");
    exit();
}

// Check seller status
if ($user['seller_status'] === 'pending') {
    // Show pending message
    $status_message = "⏳ Your seller application is pending admin approval. You'll be notified when approved.";
} elseif ($user['seller_status'] === 'rejected') {
    $status_message = "❌ Your seller application was rejected. Please contact support for more information.";
} else {
    $status_message = "✅ Your seller account is active! Start listing your items.";
}

// Get seller listings
$listings = $conn->query("
    SELECT * FROM tblSellerListings 
    WHERE seller_id = $userID 
    ORDER BY created_at DESC
");

// Get seller orders
$orders = $conn->query("
    SELECT so.*, i.name as item_name, u.fullName as buyer_name
    FROM tblSellerOrders so
    JOIN tblSellerListings i ON so.listing_id = i.listing_id
    JOIN tblUser u ON so.buyer_id = u.userID
    WHERE so.seller_id = $userID
    ORDER BY so.order_date DESC
    LIMIT 10
");

// Count stats
$totalListings = $conn->query("SELECT COUNT(*) as count FROM tblSellerListings WHERE seller_id = $userID")->fetch_assoc()['count'];
$pendingListings = $conn->query("SELECT COUNT(*) as count FROM tblSellerListings WHERE seller_id = $userID AND status = 'pending'")->fetch_assoc()['count'];
$approvedListings = $conn->query("SELECT COUNT(*) as count FROM tblSellerListings WHERE seller_id = $userID AND status = 'approved'")->fetch_assoc()['count'];
$soldListings = $conn->query("SELECT COUNT(*) as count FROM tblSellerListings WHERE seller_id = $userID AND status = 'sold'")->fetch_assoc()['count'];
$totalOrders = $conn->query("SELECT COUNT(*) as count FROM tblSellerOrders WHERE seller_id = $userID")->fetch_assoc()['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Seller Dashboard - Pastimes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,600;1,400&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: { 50: '#f4f6f0', 500: '#8da05f', 600: '#75874f' }
                    },
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'sans-serif'],
                        serif: ['Playfair Display', 'serif']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-[#f5f0e8] min-h-screen font-sans">

    <nav class="bg-white border-b border-black/5 px-8 py-4 flex justify-between items-center">
        <a href="/Pastime/splashPage.php" class="text-2xl font-serif text-brand-600 font-bold">Pastimes</a>
        <div class="flex items-center gap-6 text-sm font-medium text-neutral-600">
            <a href="/Pastime/shop.php" class="hover:text-brand-500">Browse</a>
            <a href="/Pastime/dashboard.php" class="hover:text-brand-500">Dashboard</a>
            <a href="/Pastime/logout.php" class="text-red-500 hover:text-red-600">Logout</a>
        </div>
    </nav>

    <div class="max-w-6xl mx-auto px-6 py-10">

        <!-- Header -->
        <div class="flex flex-wrap justify-between items-center mb-8">
            <div>
                <h1 class="text-3xl font-bold text-neutral-800 tracking-tight">👑 Seller Dashboard</h1>
                <p class="text-sm text-neutral-500">Welcome back, <?= htmlspecialchars($fullName) ?>!</p>
            </div>
            <div class="flex gap-3">
                <a href="list-item.php" class="bg-brand-500 text-white px-6 py-2 rounded-xl hover:bg-brand-600 transition">
                    + List New Item
                </a>
                <a href="/Pastime/shop.php" class="bg-white border border-neutral-300 text-neutral-700 px-6 py-2 rounded-xl hover:bg-neutral-50 transition">
                    View Shop
                </a>
            </div>
        </div>

        <!-- Status Message -->
        <?php if (isset($status_message)): ?>
        <div class="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6">
            <p class="text-amber-800"><?= htmlspecialchars($status_message) ?></p>
        </div>
        <?php endif; ?>

        <!-- Stats -->
        <div class="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-6 text-center">
                <div class="text-2xl font-bold text-brand-600"><?= $totalListings ?></div>
                <div class="text-sm text-neutral-500">Total Listings</div>
            </div>
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-6 text-center">
                <div class="text-2xl font-bold text-amber-600"><?= $pendingListings ?></div>
                <div class="text-sm text-neutral-500">Pending</div>
            </div>
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-6 text-center">
                <div class="text-2xl font-bold text-green-600"><?= $approvedListings ?></div>
                <div class="text-sm text-neutral-500">Approved</div>
            </div>
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-6 text-center">
                <div class="text-2xl font-bold text-neutral-600"><?= $soldListings ?></div>
                <div class="text-sm text-neutral-500">Sold</div>
            </div>
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-6 text-center">
                <div class="text-2xl font-bold text-blue-600"><?= $totalOrders ?></div>
                <div class="text-sm text-neutral-500">Orders</div>
            </div>
        </div>

        <!-- Tabs -->
        <div class="mb-6">
            <div class="border-b border-neutral-200">
                <nav class="flex gap-6" id="tabNav">
                    <button onclick="showTab('listings')" class="tab-btn py-2 px-1 text-brand-600 border-b-2 border-brand-600 font-medium text-sm" data-tab="listings">
                        📋 My Listings
                    </button>
                    <button onclick="showTab('orders')" class="tab-btn py-2 px-1 text-neutral-500 border-b-2 border-transparent font-medium text-sm hover:text-neutral-700" data-tab="orders">
                        📦 Orders
                    </button>
                    <button onclick="showTab('profile')" class="tab-btn py-2 px-1 text-neutral-500 border-b-2 border-transparent font-medium text-sm hover:text-neutral-700" data-tab="profile">
                        👤 Profile
                    </button>
                </nav>
            </div>
        </div>

        <!-- Tab Content: Listings -->
        <div id="tab-listings" class="tab-content">
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm overflow-hidden">
                <div class="px-6 py-4 bg-neutral-50/50 border-b border-neutral-100 flex justify-between items-center">
                    <h2 class="font-semibold">My Listings</h2>
                    <a href="list-item.php" class="text-brand-600 hover:underline text-sm">+ Add New</a>
                </div>

                <?php if ($listings && $listings->num_rows > 0): ?>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-neutral-50/50 border-b border-neutral-100">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Item</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Price</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Date</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-neutral-100">
                            <?php while ($item = $listings->fetch_assoc()): ?>
                            <tr>
                                <td class="px-6 py-4">
                                    <div class="flex items-center gap-3">
                                        <img src="/Pastime/images/<?= htmlspecialchars($item['image'] ?? 'default.jpg') ?>" 
                                             alt="<?= htmlspecialchars($item['name']) ?>"
                                             class="w-12 h-12 object-cover rounded-lg"
                                             onerror="this.src='/Pastime/images/default.jpg'">
                                        <div>
                                            <div class="font-medium text-neutral-800"><?= htmlspecialchars($item['name']) ?></div>
                                            <div class="text-xs text-neutral-500"><?= htmlspecialchars($item['category'] ?? 'Uncategorized') ?></div>
                                        </div>
                                    </div>
                                </td>
                                <td class="px-6 py-4 font-semibold text-brand-600">R<?= number_format($item['price'], 2) ?></td>
                                <td class="px-6 py-4">
                                    <span class="px-2 py-1 rounded-full text-xs font-medium 
                                        <?= $item['status'] === 'approved' ? 'bg-green-100 text-green-700' : 
                                           ($item['status'] === 'pending' ? 'bg-amber-100 text-amber-700' : 
                                           ($item['status'] === 'sold' ? 'bg-neutral-100 text-neutral-700' : 
                                           'bg-red-100 text-red-700')) ?>">
                                        <?= ucfirst($item['status']) ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-sm text-neutral-500"><?= date('d M Y', strtotime($item['created_at'])) ?></td>
                                <td class="px-6 py-4">
                                    <div class="flex gap-2">
                                        <?php if ($item['status'] === 'pending'): ?>
                                        <span class="text-xs text-neutral-400">Awaiting approval</span>
                                        <?php else: ?>
                                        <a href="edit-listing.php?id=<?= $item['listing_id'] ?>" class="text-blue-600 hover:underline text-sm">Edit</a>
                                        <a href="#" onclick="deleteListing(<?= $item['listing_id'] ?>)" class="text-red-500 hover:underline text-sm">Delete</a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="p-12 text-center">
                    <div class="text-4xl mb-4">📦</div>
                    <p class="text-neutral-500">You haven't listed any items yet.</p>
                    <a href="list-item.php" class="inline-block mt-4 bg-brand-500 text-white px-6 py-2 rounded-xl hover:bg-brand-600 transition">
                        List Your First Item
                    </a>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Tab Content: Orders -->
        <div id="tab-orders" class="tab-content hidden">
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm overflow-hidden">
                <div class="px-6 py-4 bg-neutral-50/50 border-b border-neutral-100">
                    <h2 class="font-semibold">Recent Orders</h2>
                </div>

                <?php if ($orders && $orders->num_rows > 0): ?>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-neutral-50/50 border-b border-neutral-100">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Order #</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Item</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Buyer</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Total</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Status</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Date</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-neutral-100">
                            <?php while ($order = $orders->fetch_assoc()): ?>
                            <tr>
                                <td class="px-6 py-4 font-mono text-sm">#<?= $order['seller_order_id'] ?></td>
                                <td class="px-6 py-4 font-medium"><?= htmlspecialchars($order['item_name']) ?></td>
                                <td class="px-6 py-4"><?= htmlspecialchars($order['buyer_name']) ?></td>
                                <td class="px-6 py-4 font-semibold text-brand-600">R<?= number_format($order['total_amount'], 2) ?></td>
                                <td class="px-6 py-4">
                                    <span class="px-2 py-1 rounded-full text-xs font-medium 
                                        <?= $order['status'] === 'delivered' ? 'bg-green-100 text-green-700' : 
                                           ($order['status'] === 'shipped' ? 'bg-blue-100 text-blue-700' : 
                                           ($order['status'] === 'processing' ? 'bg-amber-100 text-amber-700' : 
                                           'bg-neutral-100 text-neutral-700')) ?>">
                                        <?= ucfirst($order['status']) ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-sm text-neutral-500"><?= date('d M Y', strtotime($order['order_date'])) ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                <div class="p-12 text-center">
                    <div class="text-4xl mb-4">📦</div>
                    <p class="text-neutral-500">No orders yet.</p>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Tab Content: Profile -->
        <div id="tab-profile" class="tab-content hidden">
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm overflow-hidden">
                <div class="px-6 py-4 bg-neutral-50/50 border-b border-neutral-100">
                    <h2 class="font-semibold">Seller Profile</h2>
                </div>
                <div class="p-6 space-y-4">
                    <div class="grid md:grid-cols-2 gap-4">
                        <div>
                            <label class="text-sm text-neutral-500">Full Name</label>
                            <p class="font-medium"><?= htmlspecialchars($user['fullName'] ?? '') ?></p>
                        </div>
                        <div>
                            <label class="text-sm text-neutral-500">Email</label>
                            <p class="font-medium"><?= htmlspecialchars($user['email'] ?? '') ?></p>
                        </div>
                        <div>
                            <label class="text-sm text-neutral-500">Phone</label>
                            <p class="font-medium"><?= htmlspecialchars($user['seller_phone'] ?? 'Not provided') ?></p>
                        </div>
                        <div>
                            <label class="text-sm text-neutral-500">Status</label>
                            <p class="font-medium">
                                <span class="px-2 py-1 rounded-full text-xs font-medium 
                                    <?= $user['seller_status'] === 'approved' ? 'bg-green-100 text-green-700' : 
                                       ($user['seller_status'] === 'pending' ? 'bg-amber-100 text-amber-700' : 
                                       'bg-red-100 text-red-700') ?>">
                                    <?= ucfirst($user['seller_status'] ?? 'Not applied') ?>
                                </span>
                            </p>
                        </div>
                        <div class="md:col-span-2">
                            <label class="text-sm text-neutral-500">Bio</label>
                            <p class="font-medium"><?= htmlspecialchars($user['seller_bio'] ?? 'No bio provided') ?></p>
                        </div>
                        <div class="md:col-span-2">
                            <label class="text-sm text-neutral-500">Address</label>
                            <p class="font-medium"><?= htmlspecialchars($user['seller_address'] ?? 'Not provided') ?></p>
                        </div>
                    </div>
                    <div class="pt-4 border-t border-neutral-200">
                        <a href="edit-profile.php" class="text-brand-600 hover:underline text-sm">Edit Profile</a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Switch to Buyer Mode -->
        <div class="mt-8 p-4 bg-white rounded-2xl border border-neutral-200/60 shadow-sm flex flex-wrap justify-between items-center gap-4">
            <div>
                <h3 class="font-semibold">🔄 Switch to Buyer Mode</h3>
                <p class="text-sm text-neutral-500">View the shop as a buyer and purchase items</p>
            </div>
            <a href="/Pastime/shop.php" class="bg-neutral-100 text-neutral-700 px-6 py-2 rounded-xl hover:bg-neutral-200 transition">
                Browse as Buyer →
            </a>
        </div>
    </div>

    <script>
        function showTab(tabId) {
            // Hide all tabs
            document.querySelectorAll('.tab-content').forEach(el => {
                el.classList.add('hidden');
            });
            // Show selected tab
            document.getElementById('tab-' + tabId).classList.remove('hidden');
            
            // Update tab buttons
            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('text-brand-600', 'border-brand-600');
                btn.classList.add('text-neutral-500', 'border-transparent');
            });
            document.querySelector(`[data-tab="${tabId}"]`).classList.remove('text-neutral-500', 'border-transparent');
            document.querySelector(`[data-tab="${tabId}"]`).classList.add('text-brand-600', 'border-brand-600');
        }

        function deleteListing(id) {
            if (confirm('Are you sure you want to delete this listing?')) {
                window.location.href = 'delete-listing.php?id=' + id;
            }
        }
    </script>

</body>
</html>