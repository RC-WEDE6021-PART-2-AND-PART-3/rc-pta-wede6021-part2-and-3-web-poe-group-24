<?php
session_start();
require_once __DIR__ . '/../includes/DBConn.php';

if (!isset($_SESSION['userID'])) {
    header("Location: /Pastime/login.php");
    exit();
}

$userID = (int)$_SESSION['userID'];

// Check if user is an approved seller
$user = $conn->query("SELECT * FROM tblUser WHERE userID = $userID")->fetch_assoc();
if ($user['is_seller'] != 1 || $user['seller_status'] !== 'approved') {
    header("Location: dashboard.php");
    exit();
}

$message = '';
$error = '';

// Handle form submission with file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $conn->real_escape_string(trim($_POST['name'] ?? ''));
    $description = $conn->real_escape_string(trim($_POST['description'] ?? ''));
    $price = (float)$_POST['price'];
    $category = $conn->real_escape_string(trim($_POST['category'] ?? ''));
    $stock = (int)$_POST['stock'];
    
    // Check if item already exists (prevent duplicates)
    $checkDuplicate = $conn->query("SELECT listing_id FROM tblSellerListings WHERE seller_id = $userID AND name = '$name'");
    if ($checkDuplicate && $checkDuplicate->num_rows > 0) {
        $error = "❌ You already have a listing with the name '$name'. Please use a different name.";
    } else {
        // Handle image upload
        $imageName = 'default.jpg';
        if (isset($_FILES['itemImage']) && $_FILES['itemImage']['error'] === 0) {
            $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
            $ext = strtolower(pathinfo($_FILES['itemImage']['name'], PATHINFO_EXTENSION));
            if (in_array($ext, $allowed)) {
                $imageName = time() . '_' . uniqid() . '.' . $ext;
                $target = "../images/" . $imageName;
                move_uploaded_file($_FILES['itemImage']['tmp_name'], $target);
            } else {
                $error = "Invalid image format. Please use JPG, PNG, GIF, or WEBP.";
            }
        }
        
        if (empty($name) || empty($description) || $price <= 0) {
            $error = 'Please fill in all required fields.';
        } elseif (empty($error)) {
            $conn->query("
                INSERT INTO tblSellerListings (seller_id, name, description, price, category, stock, image, status)
                VALUES ($userID, '$name', '$description', $price, '$category', $stock, '$imageName', 'pending')
            ");
            
            if ($conn->affected_rows > 0) {
                $message = '✅ Item listed successfully! It will be reviewed by an admin.';
            } else {
                $error = 'Failed to list item. Please try again.';
            }
        }
    }
}

$categories = ['Tops', 'Bottoms', 'Outerwear', 'Footwear', 'Accessories'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>List Item - Pastimes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,600;1,400&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: { 50: '#f4f6f0', 500: '#8da05f', 600: '#75874f' }
                    },
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'sans-serif'],
                        serif: ['Playfair Display', 'serif']
                    }
                }
            }
        }
    </script>
    <style>
        .preview-image {
            max-width: 200px;
            max-height: 200px;
            object-fit: cover;
            border-radius: 8px;
            margin-top: 10px;
            border: 1px solid #ddd;
        }
        .file-input-wrapper {
            position: relative;
            overflow: hidden;
            display: inline-block;
            width: 100%;
        }
        .file-input-wrapper input[type=file] {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        .error-msg {
            background: #fde8e8;
            color: #c0392b;
            padding: 12px 16px;
            border-radius: 8px;
            border: 1px solid #f8c4ba;
            margin-bottom: 16px;
        }
    </style>
</head>
<body class="bg-[#f5f0e8] min-h-screen font-sans">

    <nav class="bg-white border-b border-black/5 px-8 py-4 flex justify-between items-center">
        <a href="/Pastime/splashPage.php" class="text-2xl font-serif text-brand-600 font-bold">Pastimes</a>
        <div class="flex items-center gap-6 text-sm font-medium text-neutral-600">
            <a href="/Pastime/seller/dashboard.php" class="hover:text-brand-500">Dashboard</a>
            <a href="/Pastime/logout.php" class="text-red-500 hover:text-red-600">Logout</a>
        </div>
    </nav>

    <div class="max-w-2xl mx-auto px-6 py-12">
        <div class="bg-white rounded-3xl border border-neutral-200/60 shadow-sm p-8">
            <h1 class="text-3xl font-bold text-neutral-800 tracking-tight mb-2">📦 List New Item</h1>
            <p class="text-sm text-neutral-500 mb-8">Add a new item to your seller store</p>

            <?php if ($message): ?>
            <div class="bg-green-100 text-green-700 p-4 rounded-xl mb-6"><?= htmlspecialchars($message) ?></div>
            <?php endif; ?>

            <?php if ($error): ?>
            <div class="error-msg">❌ <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <?php if (!$message): ?>
            <form method="POST" action="" enctype="multipart/form-data">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-neutral-700 mb-1">Item Name *</label>
                        <input type="text" name="name" required
                               class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                               placeholder="e.g. Vintage Levi's Jeans">
                        <p class="text-xs text-neutral-500 mt-1">Must be unique - no duplicate items allowed</p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-neutral-700 mb-1">Category *</label>
                        <select name="category" required
                                class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent">
                            <option value="">Select a category...</option>
                            <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat ?>"><?= $cat ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-neutral-700 mb-1">Description *</label>
                        <textarea name="description" rows="4" required
                                  class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                                  placeholder="Describe your item in detail..."></textarea>
                    </div>

                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-neutral-700 mb-1">Price (R) *</label>
                            <input type="number" name="price" step="0.01" required
                                   class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                                   placeholder="199.99">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-neutral-700 mb-1">Stock *</label>
                            <input type="number" name="stock" required min="1"
                                   class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                                   placeholder="1">
                        </div>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-neutral-700 mb-1">Upload Image</label>
                        <div class="file-input-wrapper">
                            <button type="button" class="w-full px-4 py-2 border-2 border-dashed border-neutral-300 rounded-lg hover:border-brand-500 transition text-neutral-500 hover:text-brand-500">
                                📁 Click to choose an image
                            </button>
                            <input type="file" name="itemImage" accept="image/*" id="imageInput" onchange="validateAndPreviewImage(event)">
                        </div>
                        <p class="text-xs text-neutral-500 mt-1">Supported formats: JPG, PNG, GIF, WEBP (Max 5MB)</p>
                        <div id="imagePreviewContainer" style="display:none; margin-top:10px;">
                            <img id="imagePreview" class="preview-image" alt="Image preview">
                            <button type="button" onclick="removeImage()" class="text-red-500 text-sm mt-1 hover:underline">Remove image</button>
                        </div>
                    </div>

                    <button type="submit" class="w-full bg-brand-500 text-white font-semibold py-3 rounded-xl hover:bg-brand-600 transition">
                        List Item
                    </button>
                </div>
            </form>
            <?php endif; ?>

            <div class="mt-6 text-center">
                <a href="/Pastime/seller/dashboard.php" class="text-neutral-500 hover:text-brand-500 text-sm">← Back to Dashboard</a>
            </div>
        </div>
    </div>

    <script>
        function validateImage(file) {
            const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
            const maxSize = 5 * 1024 * 1024;
            
            if (!allowedTypes.includes(file.type)) {
                alert('❌ Invalid file type. Please upload JPG, PNG, GIF, or WEBP images only.');
                return false;
            }
            
            if (file.size > maxSize) {
                alert('❌ File is too large. Maximum size is 5MB.');
                return false;
            }
            
            return true;
        }

        function validateAndPreviewImage(event) {
            const file = event.target.files[0];
            if (file) {
                if (!validateImage(file)) {
                    event.target.value = '';
                    return;
                }
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('imagePreview').src = e.target.result;
                    document.getElementById('imagePreviewContainer').style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        }

        function removeImage() {
            document.getElementById('imageInput').value = '';
            document.getElementById('imagePreviewContainer').style.display = 'none';
            document.getElementById('imagePreview').src = '';
        }
    </script>

</body>
</html>