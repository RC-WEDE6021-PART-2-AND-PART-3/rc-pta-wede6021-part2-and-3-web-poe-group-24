<?php
session_start();
require_once __DIR__ . '/includes/DBConn.php';

if (!isset($_SESSION['userID'])) {
    header("Location: splashPage.php");
    exit();
}

$userID = (int)$_SESSION['userID'];

// Handle remove item
if (isset($_GET['remove'])) {
    $removeID = (int)$_GET['remove'];
    $conn->query("DELETE FROM tblCart WHERE userID = $userID AND clothesID = $removeID");
    header("Location: cart.php");
    exit();
}

// Handle update quantity
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    $clothesID = (int)$_POST['clothesID'];
    $quantity = (int)$_POST['quantity'];
    if ($quantity <= 0) {
        $conn->query("DELETE FROM tblCart WHERE userID = $userID AND clothesID = $clothesID");
    } else {
        $conn->query("UPDATE tblCart SET quantity = $quantity WHERE userID = $userID AND clothesID = $clothesID");
    }
    header("Location: cart.php");
    exit();
}

// Get cart items with product details
$items = [];
$total = 0;
$count = 0;

$result = $conn->query("
    SELECT c.*, i.name, i.price, i.image, i.stock, i.category
    FROM tblCart c
    JOIN tbl_Item i ON c.clothesID = i.clothesID
    WHERE c.userID = $userID
");

if ($result) {
    while ($row = $result->fetch_assoc()) {
        $clothesID = $row['clothesID'];
        $items[$clothesID] = [
            'name' => $row['name'],
            'price' => $row['price'],
            'image' => $row['image'],
            'quantity' => $row['quantity'],
            'stock' => $row['stock'],
            'category' => $row['category'] ?? 'Uncategorized'
        ];
        $total += $row['price'] * $row['quantity'];
        $count += $row['quantity'];
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Shopping Cart - Pastimes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,600;1,400&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: { 50: '#f4f6f0', 500: '#8da05f', 600: '#75874f' }
                    },
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'sans-serif'],
                        serif: ['Playfair Display', 'serif']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-[#f5f0e8] min-h-screen font-sans">

    <nav class="bg-white border-b border-black/5 px-8 py-4 flex justify-between items-center">
        <a href="splashPage.php" class="text-2xl font-serif text-brand-600 font-bold">Pastimes</a>
        <div class="flex items-center gap-6 text-sm font-medium text-neutral-600">
            <a href="shop.php" class="hover:text-brand-500">Continue Shopping</a>
            <a href="dashboard.php" class="hover:text-brand-500">Dashboard</a>
            <a href="logout.php" class="text-red-500 hover:text-red-600">Logout</a>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto px-6 py-10">
        <h1 class="text-3xl font-bold text-neutral-800 tracking-tight mb-2">🛒 Shopping Cart</h1>
        <p class="text-sm text-neutral-500 mb-8">Review the items in your cart</p>

        <?php if (empty($items)): ?>
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-12 text-center">
                <div class="text-6xl mb-4">🛍️</div>
                <p class="text-neutral-500 text-lg">Your cart is empty</p>
                <p class="text-sm text-neutral-400">Start shopping and add some items!</p>
                <a href="shop.php" class="inline-block mt-4 bg-brand-500 text-white px-6 py-3 rounded-xl font-semibold hover:bg-brand-600 transition">
                    Start Shopping →
                </a>
            </div>
        <?php else: ?>
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm overflow-hidden">
                <!-- Header -->
                <div class="hidden md:grid md:grid-cols-6 gap-4 px-6 py-3 bg-neutral-50/50 border-b border-neutral-100 text-sm font-medium text-neutral-500">
                    <div class="col-span-2">Item</div>
                    <div>Category</div>
                    <div>Price</div>
                    <div>Quantity</div>
                    <div class="text-right">Subtotal</div>
                </div>

                <!-- Items -->
                <?php foreach ($items as $clothesID => $item): ?>
                <div class="grid grid-cols-2 md:grid-cols-6 gap-4 px-4 md:px-6 py-4 border-b border-neutral-100 items-center">
                    <div class="col-span-2 flex items-center gap-3">
                        <img src="/Pastime/images/<?= htmlspecialchars($item['image'] ?? 'default.jpg') ?>" 
                             alt="<?= htmlspecialchars($item['name']) ?>"
                             class="w-16 h-16 object-cover rounded-lg"
                             onerror="this.src='/Pastime/images/default.jpg'">
                        <div>
                            <h3 class="font-medium text-neutral-800"><?= htmlspecialchars($item['name']) ?></h3>
                            <a href="cart.php?remove=<?= $clothesID ?>" class="text-xs text-red-500 hover:underline" onclick="return confirm('Remove this item?')">Remove</a>
                        </div>
                    </div>
                    <div class="text-xs text-neutral-500 hidden md:block"><?= htmlspecialchars($item['category']) ?></div>
                    <div class="text-brand-600 font-semibold">R<?= number_format($item['price'], 2) ?></div>
                    <div>
                        <form method="POST" action="" class="flex items-center gap-2">
                            <input type="hidden" name="clothesID" value="<?= $clothesID ?>">
                            <input type="number" name="quantity" value="<?= $item['quantity'] ?>" min="1" max="<?= $item['stock'] ?? 99 ?>"
                                   class="w-16 px-2 py-1 border border-neutral-300 rounded-lg text-center">
                            <button type="submit" name="update" class="text-sm text-brand-500 hover:underline">Update</button>
                        </form>
                    </div>
                    <div class="text-right font-semibold text-neutral-800">R<?= number_format($item['price'] * $item['quantity'], 2) ?></div>
                </div>
                <?php endforeach; ?>

                <!-- Total -->
                <div class="px-6 py-4 bg-neutral-50/50 border-t border-neutral-100">
                    <div class="flex justify-between items-center">
                        <span class="text-sm text-neutral-500">Total (<?= $count ?> items)</span>
                        <span class="text-2xl font-bold text-brand-600">R<?= number_format($total, 2) ?></span>
                    </div>
                </div>
            </div>

            <div class="mt-6 flex flex-col sm:flex-row gap-4 justify-end">
                <a href="shop.php" class="text-neutral-500 hover:text-brand-500 py-2 px-4 text-center">← Continue Shopping</a>
                <a href="checkout.php" class="bg-brand-500 text-white px-8 py-3 rounded-xl font-semibold hover:bg-brand-600 transition text-center">
                    Proceed to Checkout →
                </a>
            </div>
        <?php endif; ?>
    </div>

</body>
</html>