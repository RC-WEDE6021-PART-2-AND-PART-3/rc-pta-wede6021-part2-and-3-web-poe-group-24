<?php
session_start();
require_once __DIR__ . '/includes/DBConn.php';

if (!isset($_SESSION['adminID']) && !isset($_SESSION['userID'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle sending message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $receiverID = (int)$_POST['receiver_id'];
    $message = $conn->real_escape_string($_POST['message']);
    $senderID = $_SESSION['adminID'] ?? 1;
    
    $conn->query("INSERT INTO tblCommunications (senderID, receiverID, message) 
                  VALUES ($senderID, $receiverID, '$message')");
    $success = "Message sent successfully!";
}

// Get all users for dropdown
$users = $conn->query("SELECT userID, fullName, email FROM tblUser ORDER BY fullName");

// Get all communications
$messages = $conn->query("
    SELECT c.*, 
           sender.fullName as senderName,
           receiver.fullName as receiverName
    FROM tblCommunications c
    LEFT JOIN tblUser sender ON c.senderID = sender.userID
    LEFT JOIN tblUser receiver ON c.receiverID = receiver.userID
    ORDER BY c.sentDate DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Communications - Pastimes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="bg-[#f5f0e8] font-sans">

    <nav class="bg-white border-b border-black/5 px-8 py-4 flex justify-between items-center">
        <a href="admin_dashboard.php" class="text-2xl font-serif text-[#8da05f] font-bold">👑 Admin</a>
        <div class="flex items-center gap-6 text-sm font-medium text-neutral-600">
            <a href="admin_dashboard.php" class="hover:text-[#8da05f]">Dashboard</a>
            <a href="admin_clothes.php" class="hover:text-[#8da05f]">Clothes</a>
            <a href="admin_communications.php" class="text-[#8da05f] font-bold">Communications</a>
            <a href="logout.php" class="text-red-500 hover:text-red-600">Logout</a>
        </div>
    </nav>

    <div class="max-w-6xl mx-auto px-6 py-10">
        <h1 class="text-3xl font-bold text-neutral-800 tracking-tight mb-2">💬 Communications</h1>
        <p class="text-sm text-neutral-500 mb-8">Send messages to users and view all communications</p>

        <?php if (isset($success)): ?>
        <div class="bg-green-100 text-green-700 p-4 rounded-xl mb-6">✅ <?= htmlspecialchars($success) ?></div>
        <?php endif; ?>

        <div class="grid md:grid-cols-2 gap-6">
            <!-- Send Message -->
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-6">
                <h2 class="font-semibold text-lg mb-4">Send Message</h2>
                <form method="POST" action="">
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-neutral-700 mb-1">Select User</label>
                        <select name="receiver_id" class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#8da05f] focus:border-transparent">
                            <option value="">Select a user...</option>
                            <?php while ($user = $users->fetch_assoc()): ?>
                            <option value="<?= $user['userID'] ?>">
                                <?= htmlspecialchars($user['fullName']) ?> (<?= htmlspecialchars($user['email']) ?>)
                            </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-neutral-700 mb-1">Message</label>
                        <textarea name="message" rows="4" class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#8da05f] focus:border-transparent" required></textarea>
                    </div>
                    <button type="submit" name="send_message" class="bg-[#8da05f] text-white px-6 py-2 rounded-lg hover:bg-[#75874f] transition">
                        Send Message
                    </button>
                </form>
            </div>

            <!-- Message History -->
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-6">
                <h2 class="font-semibold text-lg mb-4">Message History</h2>
                <?php if ($messages && $messages->num_rows > 0): ?>
                    <div class="space-y-4 max-h-96 overflow-y-auto">
                        <?php while ($msg = $messages->fetch_assoc()): ?>
                        <div class="border-b border-neutral-100 pb-3 last:border-0">
                            <div class="flex justify-between text-sm">
                                <span class="font-medium">From: <?= htmlspecialchars($msg['senderName'] ?? 'System') ?></span>
                                <span class="text-neutral-400 text-xs"><?= date('d M Y H:i', strtotime($msg['sentDate'])) ?></span>
                            </div>
                            <div class="text-sm text-neutral-600">To: <?= htmlspecialchars($msg['receiverName'] ?? 'Unknown') ?></div>
                            <p class="text-neutral-800 mt-1"><?= htmlspecialchars($msg['message']) ?></p>
                            <?php if (!$msg['isRead']): ?>
                            <span class="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full">Unread</span>
                            <?php endif; ?>
                        </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <p class="text-neutral-500 text-center py-8">No messages yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

</body>
</html>