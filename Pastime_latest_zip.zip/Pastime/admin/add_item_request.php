<?php
session_start();
if (!isset($_SESSION['userID'])) {
    header("Location: login.php");
    exit();
}

require "includes/DBConn.php";

$message = "";
$error = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $userID = $_SESSION['userID'];
    $itemName = $conn->real_escape_string(trim($_POST['itemName']));
    $description = $conn->real_escape_string(trim($_POST['description'] ?? ''));
    $itemPrice = (float)$_POST['itemPrice'];
    $brand = $conn->real_escape_string(trim($_POST['brand'] ?? ''));
    
    // Handle image upload
    $imageName = 'default.jpg';
    if (isset($_FILES['itemImage']) && $_FILES['itemImage']['error'] === 0) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $ext = strtolower(pathinfo($_FILES['itemImage']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, $allowed)) {
            $imageName = time() . '_' . uniqid() . '.' . $ext;
            $target = "images/" . $imageName;
            move_uploaded_file($_FILES['itemImage']['tmp_name'], $target);
        } else {
            $error = "Invalid image format. Please use JPG, PNG, GIF, or WEBP.";
        }
    }
    
    if (empty($error)) {
        $sql = "INSERT INTO tblSellerRequests (userID, itemName, description, itemPrice, brand, image, status)
                VALUES ($userID, '$itemName', '$description', $itemPrice, '$brand', '$imageName', 'Pending')";
        
        if ($conn->query($sql)) {
            $message = "✅ Your listing request has been submitted for administrator approval!";
        } else {
            $error = "Error submitting request: " . $conn->error;
        }
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit Listing - Pastimes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="bg-[#f5f0e8] min-h-screen font-sans">

    <nav class="bg-white border-b border-black/5 px-8 py-4 flex justify-between items-center">
        <a href="splashPage.php" class="text-2xl font-serif text-[#8da05f] font-bold">Pastimes</a>
        <div class="flex items-center gap-6 text-sm font-medium text-neutral-600">
            <a href="shop.php" class="hover:text-[#8da05f]">Browse</a>
            <a href="dashboard.php" class="hover:text-[#8da05f]">Dashboard</a>
            <a href="logout.php" class="text-rose-500 hover:text-rose-600">Logout</a>
        </div>
    </nav>

    <div class="max-w-2xl mx-auto px-6 py-12">
        <div class="bg-white rounded-3xl shadow-xl p-8 border border-neutral-100">
            <div class="text-center mb-8">
                <h1 class="text-2xl font-bold text-neutral-800 tracking-tight">📦 List an Item for Sale</h1>
                <p class="text-sm text-neutral-500 mt-1">Submit your pre-loved clothing for admin verification</p>
            </div>

            <?php if (!empty($message)): ?>
                <div class="mb-6 p-4 bg-emerald-50 border-l-4 border-emerald-500 rounded-r-xl text-emerald-700 text-sm font-medium">
                    <?= htmlspecialchars($message) ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error)): ?>
                <div class="mb-6 p-4 bg-rose-50 border-l-4 border-rose-500 rounded-r-xl text-rose-700 text-sm font-medium">
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" class="space-y-5">
                <div>
                    <label class="block text-xs font-semibold uppercase tracking-wider text-neutral-500 mb-2">Item Name *</label>
                    <input type="text" name="itemName" required
                           class="w-full px-4 py-3 rounded-xl border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-[#8da05f]/40"
                           placeholder="e.g., Vintage Levi's Denim Jacket">
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase tracking-wider text-neutral-500 mb-2">Description</label>
                    <textarea name="description" rows="3"
                              class="w-full px-4 py-3 rounded-xl border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-[#8da05f]/40"
                              placeholder="Describe the item's condition, size, material, etc."></textarea>
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase tracking-wider text-neutral-500 mb-2">Brand</label>
                    <input type="text" name="brand"
                           class="w-full px-4 py-3 rounded-xl border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-[#8da05f]/40"
                           placeholder="e.g., Levi's, Nike, Zara">
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase tracking-wider text-neutral-500 mb-2">Price (ZAR) *</label>
                    <input type="number" name="itemPrice" required min="1" step="0.01"
                           class="w-full px-4 py-3 rounded-xl border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-[#8da05f]/40"
                           placeholder="350.00">
                </div>

                <div>
                    <label class="block text-xs font-semibold uppercase tracking-wider text-neutral-500 mb-2">Upload Image *</label>
                    <input type="file" name="itemImage" accept="image/*" required
                           class="w-full text-sm text-neutral-500 file:mr-4 file:py-2.5 file:px-6 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-[#8da05f] file:text-white hover:file:bg-[#75874f] cursor-pointer">
                </div>

                <button type="submit"
                        class="w-full bg-[#8da05f] hover:bg-[#75874f] text-white font-semibold py-3.5 rounded-xl transition shadow-md shadow-[#8da05f]/20 transform hover:-translate-y-0.5 duration-200">
                    Submit for Verification
                </button>
            </form>

            <div class="mt-6 text-center">
                <a href="dashboard.php" class="text-sm text-neutral-500 hover:text-[#8da05f] transition">← Back to Dashboard</a>
            </div>
        </div>
    </div>
</body>
</html>