<?php
session_start();
require_once __DIR__ . '/../includes/DBConn.php';

// Check admin access
if (!isset($_SESSION['adminID']) && !isset($_SESSION['userID'])) {
    header("Location: admin_login.php");
    exit();
}

$message = '';

// Handle listing actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $listingID = (int)$_POST['listing_id'];
    $action = $_POST['action'];
    
    if ($action === 'approve') {
        $conn->query("UPDATE tblSellerListings SET status = 'approved' WHERE listing_id = $listingID");
        $message = "✅ Listing approved!";
    } elseif ($action === 'reject') {
        $conn->query("UPDATE tblSellerListings SET status = 'rejected' WHERE listing_id = $listingID");
        $message = "❌ Listing rejected.";
    } elseif ($action === 'delete') {
        $conn->query("DELETE FROM tblSellerListings WHERE listing_id = $listingID");
        $message = "🗑️ Listing deleted.";
    }
}

// Get all pending listings - FIXED: use created_at (this column exists in tblSellerListings)
$pendingListings = $conn->query("
    SELECT l.*, u.fullName, u.email 
    FROM tblSellerListings l
    JOIN tblUser u ON l.seller_id = u.userID
    WHERE l.status = 'pending'
    ORDER BY l.created_at DESC
");

// Get all approved listings - FIXED: use created_at (this column exists in tblSellerListings)
$approvedListings = $conn->query("
    SELECT l.*, u.fullName, u.email 
    FROM tblSellerListings l
    JOIN tblUser u ON l.seller_id = u.userID
    WHERE l.status = 'approved'
    ORDER BY l.created_at DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Listings - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="bg-[#f5f0e8] font-sans">

    <nav class="bg-white border-b border-black/5 px-8 py-4 flex justify-between items-center">
        <a href="dashboard.php" class="text-2xl font-serif text-[#8da05f] font-bold">👑 Admin</a>
        <div class="flex items-center gap-6 text-sm font-medium text-neutral-600">
            <a href="dashboard.php" class="hover:text-[#8da05f]">Dashboard</a>
            <a href="manage-sellers.php" class="hover:text-[#8da05f]">Sellers</a>
            <a href="manage-listings.php" class="text-[#8da05f] font-bold">Listings</a>
            <a href="../logout.php" class="text-red-500 hover:text-red-600">Logout</a>
        </div>
    </nav>

    <div class="max-w-6xl mx-auto px-6 py-10">
        <h1 class="text-3xl font-bold text-neutral-800 tracking-tight mb-2">📦 Manage Listings</h1>
        <p class="text-sm text-neutral-500 mb-8">Approve or reject seller listings</p>

        <?php if ($message): ?>
        <div class="bg-green-100 text-green-700 p-4 rounded-xl mb-6"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <!-- Pending Listings -->
        <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm overflow-hidden mb-8">
            <div class="px-6 py-4 bg-amber-50 border-b border-amber-200">
                <h2 class="font-semibold text-amber-800">⏳ Pending Listings</h2>
            </div>
            <?php if ($pendingListings && $pendingListings->num_rows > 0): ?>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-neutral-50/50 border-b border-neutral-100">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Item</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Seller</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Price</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Date</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-neutral-100">
                        <?php while ($item = $pendingListings->fetch_assoc()): ?>
                        <tr>
                            <td class="px-6 py-4">
                                <div class="flex items-center gap-3">
                                    <img src="/Pastime/images/<?= htmlspecialchars($item['image'] ?? 'default.jpg') ?>" 
                                         alt="<?= htmlspecialchars($item['name']) ?>"
                                         class="w-12 h-12 object-cover rounded-lg"
                                         onerror="this.src='/Pastime/images/default.jpg'">
                                    <div>
                                        <div class="font-medium text-neutral-800"><?= htmlspecialchars($item['name']) ?></div>
                                        <div class="text-xs text-neutral-500"><?= htmlspecialchars($item['category'] ?? 'Uncategorized') ?></div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="font-medium"><?= htmlspecialchars($item['fullName']) ?></div>
                                <div class="text-xs text-neutral-500"><?= htmlspecialchars($item['email']) ?></div>
                            </td>
                            <td class="px-6 py-4 font-semibold text-brand-600">R<?= number_format($item['price'], 2) ?></td>
                            <td class="px-6 py-4 text-sm text-neutral-500"><?= date('d M Y', strtotime($item['created_at'])) ?></td>
                            <td class="px-6 py-4">
                                <div class="flex gap-2 flex-wrap">
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="listing_id" value="<?= $item['listing_id'] ?>">
                                        <button type="submit" name="action" value="approve" class="bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600 transition">✅ Approve</button>
                                    </form>
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="listing_id" value="<?= $item['listing_id'] ?>">
                                        <button type="submit" name="action" value="reject" class="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600 transition">❌ Reject</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="p-8 text-center text-neutral-500">No pending listings.</div>
            <?php endif; ?>
        </div>

        <!-- Approved Listings -->
        <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm overflow-hidden">
            <div class="px-6 py-4 bg-green-50 border-b border-green-200">
                <h2 class="font-semibold text-green-800">✅ Approved Listings</h2>
            </div>
            <?php if ($approvedListings && $approvedListings->num_rows > 0): ?>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-neutral-50/50 border-b border-neutral-100">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Item</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Seller</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Price</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-neutral-100">
                        <?php while ($item = $approvedListings->fetch_assoc()): ?>
                        <tr>
                            <td class="px-6 py-4">
                                <div class="flex items-center gap-3">
                                    <img src="/Pastime/images/<?= htmlspecialchars($item['image'] ?? 'default.jpg') ?>" 
                                         alt="<?= htmlspecialchars($item['name']) ?>"
                                         class="w-12 h-12 object-cover rounded-lg"
                                         onerror="this.src='/Pastime/images/default.jpg'">
                                    <div>
                                        <div class="font-medium text-neutral-800"><?= htmlspecialchars($item['name']) ?></div>
                                        <div class="text-xs text-neutral-500"><?= htmlspecialchars($item['category'] ?? 'Uncategorized') ?></div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4">
                                <div class="font-medium"><?= htmlspecialchars($item['fullName']) ?></div>
                                <div class="text-xs text-neutral-500"><?= htmlspecialchars($item['email']) ?></div>
                            </td>
                            <td class="px-6 py-4 font-semibold text-brand-600">R<?= number_format($item['price'], 2) ?></td>
                            <td class="px-6 py-4">
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="listing_id" value="<?= $item['listing_id'] ?>">
                                    <button type="submit" name="action" value="delete" class="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600 transition" onclick="return confirm('Delete this listing?')">🗑️ Delete</button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="p-8 text-center text-neutral-500">No approved listings yet.</div>
            <?php endif; ?>
        </div>

        <div class="mt-6 text-center">
            <a href="dashboard.php" class="text-neutral-500 hover:text-[#8da05f] text-sm">← Back to Admin Dashboard</a>
        </div>
    </div>

</body>
</html>