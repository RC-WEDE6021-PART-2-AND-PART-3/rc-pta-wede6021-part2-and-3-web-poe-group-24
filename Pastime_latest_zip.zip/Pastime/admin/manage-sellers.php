<?php
session_start();
require_once __DIR__ . '/../includes/DBConn.php';

// Check admin access
if (!isset($_SESSION['adminID']) && !isset($_SESSION['userID'])) {
    header("Location: admin_login.php");
    exit();
}

$message = '';
$error = '';

// Handle approval/rejection
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $userID = (int)$_POST['user_id'];
    $action = $_POST['action'];
    
    if ($action === 'approve') {
        $conn->query("UPDATE tblUser SET seller_status = 'approved' WHERE userID = $userID");
        $message = "✅ Seller approved successfully!";
    } elseif ($action === 'reject') {
        $conn->query("UPDATE tblUser SET seller_status = 'rejected' WHERE userID = $userID");
        $message = "❌ Seller rejected.";
    } elseif ($action === 'delete') {
        $conn->query("UPDATE tblUser SET is_seller = 0, seller_status = NULL WHERE userID = $userID");
        $message = "🗑️ Seller removed.";
    }
}

// Get all pending sellers - FIXED: use createdAt instead of created_at
$pendingSellers = $conn->query("
    SELECT * FROM tblUser 
    WHERE is_seller = 1 AND seller_status = 'pending'
    ORDER BY seller_application_date DESC
");

// Get all approved sellers - FIXED: use createdAt instead of created_at
$approvedSellers = $conn->query("
    SELECT * FROM tblUser 
    WHERE is_seller = 1 AND seller_status = 'approved'
    ORDER BY createdAt DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Sellers - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="bg-[#f5f0e8] font-sans">

    <nav class="bg-white border-b border-black/5 px-8 py-4 flex justify-between items-center">
        <a href="dashboard.php" class="text-2xl font-serif text-[#8da05f] font-bold">👑 Admin</a>
        <div class="flex items-center gap-6 text-sm font-medium text-neutral-600">
            <a href="dashboard.php" class="hover:text-[#8da05f]">Dashboard</a>
            <a href="manage-sellers.php" class="text-[#8da05f] font-bold">Sellers</a>
            <a href="manage-listings.php" class="hover:text-[#8da05f]">Listings</a>
            <a href="../logout.php" class="text-red-500 hover:text-red-600">Logout</a>
        </div>
    </nav>

    <div class="max-w-6xl mx-auto px-6 py-10">
        <h1 class="text-3xl font-bold text-neutral-800 tracking-tight mb-2">👑 Manage Sellers</h1>
        <p class="text-sm text-neutral-500 mb-8">Approve or reject seller applications</p>

        <?php if ($message): ?>
        <div class="bg-green-100 text-green-700 p-4 rounded-xl mb-6"><?= htmlspecialchars($message) ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
        <div class="bg-red-100 text-red-700 p-4 rounded-xl mb-6">❌ <?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <!-- Pending Sellers -->
        <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm overflow-hidden mb-8">
            <div class="px-6 py-4 bg-amber-50 border-b border-amber-200">
                <h2 class="font-semibold text-amber-800">⏳ Pending Applications</h2>
            </div>
            <?php if ($pendingSellers && $pendingSellers->num_rows > 0): ?>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-neutral-50/50 border-b border-neutral-100">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Name</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Email</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Phone</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Bio</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-neutral-100">
                        <?php while ($seller = $pendingSellers->fetch_assoc()): ?>
                        <tr>
                            <td class="px-6 py-4 font-medium"><?= htmlspecialchars($seller['fullName']) ?></td>
                            <td class="px-6 py-4 text-sm"><?= htmlspecialchars($seller['email']) ?></td>
                            <td class="px-6 py-4 text-sm"><?= htmlspecialchars($seller['seller_phone'] ?? 'N/A') ?></td>
                            <td class="px-6 py-4 text-sm max-w-xs truncate"><?= htmlspecialchars(substr($seller['seller_bio'] ?? '', 0, 100)) ?></td>
                            <td class="px-6 py-4">
                                <div class="flex gap-2 flex-wrap">
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="user_id" value="<?= $seller['userID'] ?>">
                                        <button type="submit" name="action" value="approve" class="bg-green-500 text-white px-3 py-1 rounded text-sm hover:bg-green-600 transition">✅ Approve</button>
                                    </form>
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="user_id" value="<?= $seller['userID'] ?>">
                                        <button type="submit" name="action" value="reject" class="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600 transition">❌ Reject</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="p-8 text-center text-neutral-500">No pending applications.</div>
            <?php endif; ?>
        </div>

        <!-- Approved Sellers -->
        <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm overflow-hidden">
            <div class="px-6 py-4 bg-green-50 border-b border-green-200">
                <h2 class="font-semibold text-green-800">✅ Approved Sellers</h2>
            </div>
            <?php if ($approvedSellers && $approvedSellers->num_rows > 0): ?>
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-neutral-50/50 border-b border-neutral-100">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Name</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Email</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Listings</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Joined</th>
                            <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-neutral-100">
                        <?php while ($seller = $approvedSellers->fetch_assoc()): 
                            $listingCount = 0;
                            $countResult = $conn->query("SELECT COUNT(*) as count FROM tblSellerListings WHERE seller_id = {$seller['userID']}");
                            if ($countResult) {
                                $listingCount = $countResult->fetch_assoc()['count'];
                            }
                        ?>
                        <tr>
                            <td class="px-6 py-4 font-medium"><?= htmlspecialchars($seller['fullName']) ?></td>
                            <td class="px-6 py-4 text-sm"><?= htmlspecialchars($seller['email']) ?></td>
                            <td class="px-6 py-4 text-center"><?= $listingCount ?></td>
                            <td class="px-6 py-4 text-sm text-neutral-500"><?= date('d M Y', strtotime($seller['createdAt'] ?? 'now')) ?></td>
                            <td class="px-6 py-4">
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="user_id" value="<?= $seller['userID'] ?>">
                                    <button type="submit" name="action" value="delete" class="bg-red-500 text-white px-3 py-1 rounded text-sm hover:bg-red-600 transition" onclick="return confirm('Remove this seller? This cannot be undone.')">🗑️ Remove</button>
                                </form>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div class="p-8 text-center text-neutral-500">No approved sellers yet.</div>
            <?php endif; ?>
        </div>

        <div class="mt-6 text-center">
            <a href="dashboard.php" class="text-neutral-500 hover:text-[#8da05f] text-sm">← Back to Admin Dashboard</a>
        </div>
    </div>

</body>
</html>