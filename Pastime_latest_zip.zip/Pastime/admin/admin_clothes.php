<?php
session_start();
require_once __DIR__ . '/includes/DBConn.php';

if (!isset($_SESSION['adminID'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle Add
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if ($action === 'add') {
        $name = $conn->real_escape_string($_POST['name']);
        $description = $conn->real_escape_string($_POST['description']);
        $price = (float)$_POST['price'];
        $stock = (int)$_POST['stock'];
        $image = $conn->real_escape_string($_POST['image'] ?? 'default.jpg');
        
        $conn->query("INSERT INTO tbl_Item (name, description, price, stock, image) 
                     VALUES ('$name', '$description', $price, $stock, '$image')");
        $conn->query("INSERT INTO tblClothes (name, description, price, stock, image) 
                     VALUES ('$name', '$description', $price, $stock, '$image')");
        
        header("Location: admin_clothes.php?added=1");
        exit();
    }
    
    if ($action === 'edit') {
        $id = (int)$_POST['clothesID'];
        $name = $conn->real_escape_string($_POST['name']);
        $description = $conn->real_escape_string($_POST['description']);
        $price = (float)$_POST['price'];
        $stock = (int)$_POST['stock'];
        $image = $conn->real_escape_string($_POST['image'] ?? 'default.jpg');
        
        $conn->query("UPDATE tbl_Item SET 
                     name = '$name', description = '$description', 
                     price = $price, stock = $stock, image = '$image'
                     WHERE clothesID = $id");
        $conn->query("UPDATE tblClothes SET 
                     name = '$name', description = '$description', 
                     price = $price, stock = $stock, image = '$image'
                     WHERE clothesID = $id");
        
        header("Location: admin_clothes.php?edited=1");
        exit();
    }
    
    if ($action === 'delete') {
        $id = (int)$_POST['clothesID'];
        $conn->query("DELETE FROM tbl_Item WHERE clothesID = $id");
        $conn->query("DELETE FROM tblClothes WHERE clothesID = $id");
        
        header("Location: admin_clothes.php?deleted=1");
        exit();
    }
}

// Fetch all items
$items = $conn->query("SELECT * FROM tbl_Item ORDER BY clothesID ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Clothes Management - Pastimes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="bg-[#f5f0e8] font-sans">

    <nav class="bg-white border-b border-black/5 px-8 py-4 flex justify-between items-center">
        <a href="admin_dashboard.php" class="text-2xl font-serif text-[#8da05f] font-bold">👑 Admin</a>
        <div class="flex items-center gap-6 text-sm font-medium text-neutral-600">
            <a href="admin_dashboard.php" class="hover:text-[#8da05f]">Dashboard</a>
            <a href="admin_clothes.php" class="text-[#8da05f] font-bold">Clothes</a>
            <a href="admin_communications.php" class="hover:text-[#8da05f]">Communications</a>
            <a href="logout.php" class="text-red-500 hover:text-red-600">Logout</a>
        </div>
    </nav>

    <div class="max-w-6xl mx-auto px-6 py-10">
        <div class="flex justify-between items-center mb-8">
            <div>
                <h1 class="text-3xl font-bold text-neutral-800 tracking-tight">👕 Clothes Management</h1>
                <p class="text-sm text-neutral-500">Add, edit, or remove items from your store</p>
            </div>
            <button onclick="openModal('addModal')" class="bg-[#8da05f] text-white px-6 py-2 rounded-xl hover:bg-[#75874f] transition">
                + Add New Item
            </button>
        </div>

        <?php if (isset($_GET['added'])): ?>
        <div class="bg-green-100 text-green-700 p-4 rounded-xl mb-6">✅ Item added successfully!</div>
        <?php endif; ?>
        <?php if (isset($_GET['edited'])): ?>
        <div class="bg-green-100 text-green-700 p-4 rounded-xl mb-6">✅ Item updated successfully!</div>
        <?php endif; ?>
        <?php if (isset($_GET['deleted'])): ?>
        <div class="bg-green-100 text-green-700 p-4 rounded-xl mb-6">✅ Item deleted successfully!</div>
        <?php endif; ?>

        <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm overflow-hidden">
            <table class="w-full">
                <thead class="bg-neutral-50/50 border-b border-neutral-100">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">ID</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Image</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Price</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Stock</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-neutral-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-neutral-100">
                    <?php if ($items && $items->num_rows > 0): ?>
                        <?php while ($row = $items->fetch_assoc()): ?>
                        <tr class="hover:bg-neutral-50/30 transition">
                            <td class="px-6 py-4 text-sm text-neutral-500">#<?= $row['clothesID'] ?></td>
                            <td class="px-6 py-4">
                                <img src="/Pastime/images/<?= htmlspecialchars($row['image'] ?? 'default.jpg') ?>" 
                                     alt="<?= htmlspecialchars($row['name']) ?>"
                                     class="w-12 h-12 object-cover rounded-lg"
                                     onerror="this.src='/Pastime/images/default.jpg'">
                            </td>
                            <td class="px-6 py-4 font-medium text-neutral-800"><?= htmlspecialchars($row['name']) ?></td>
                            <td class="px-6 py-4 text-brand-600 font-semibold">R<?= number_format($row['price'], 2) ?></td>
                            <td class="px-6 py-4">
                                <span class="px-2 py-1 rounded-full text-xs font-medium <?= $row['stock'] > 10 ? 'bg-green-100 text-green-700' : ($row['stock'] > 0 ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700') ?>">
                                    <?= $row['stock'] ?> units
                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <div class="flex gap-2">
                                    <button onclick='editItem(<?= json_encode($row) ?>)' class="text-blue-600 hover:text-blue-800 text-sm font-medium">Edit</button>
                                    <form method="POST" onsubmit="return confirm('Delete this item?')" class="inline">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="clothesID" value="<?= $row['clothesID'] ?>">
                                        <button type="submit" class="text-red-500 hover:text-red-700 text-sm font-medium">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="px-6 py-12 text-center text-neutral-500">No items found. Add your first item!</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Modal -->
    <div id="addModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50 hidden">
        <div class="bg-white rounded-2xl p-8 max-w-md w-full mx-4">
            <h2 class="text-2xl font-bold text-neutral-800 mb-4">➕ Add New Item</h2>
            <form method="POST">
                <input type="hidden" name="action" value="add">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-neutral-700">Item Name *</label>
                        <input type="text" name="name" required class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#8da05f]">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-neutral-700">Description</label>
                        <textarea name="description" rows="3" class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#8da05f]"></textarea>
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-neutral-700">Price (R) *</label>
                            <input type="number" name="price" step="0.01" required class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#8da05f]">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-neutral-700">Stock *</label>
                            <input type="number" name="stock" required class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#8da05f]">
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-neutral-700">Image Filename</label>
                        <input type="text" name="image" placeholder="default.jpg" class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#8da05f]">
                    </div>
                </div>
                <div class="flex gap-3 mt-6">
                    <button type="button" onclick="closeModal('addModal')" class="flex-1 px-4 py-2 border border-neutral-300 rounded-lg hover:bg-neutral-50 transition">Cancel</button>
                    <button type="submit" class="flex-1 bg-[#8da05f] text-white px-4 py-2 rounded-lg hover:bg-[#75874f] transition">Add Item</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Modal -->
    <div id="editModal" class="fixed inset-0 bg-black/50 flex items-center justify-center z-50 hidden">
        <div class="bg-white rounded-2xl p-8 max-w-md w-full mx-4">
            <h2 class="text-2xl font-bold text-neutral-800 mb-4">✏️ Edit Item</h2>
            <form method="POST" id="editForm">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="clothesID" id="editID">
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-neutral-700">Item Name *</label>
                        <input type="text" name="name" id="editName" required class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#8da05f]">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-neutral-700">Description</label>
                        <textarea name="description" id="editDescription" rows="3" class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#8da05f]"></textarea>
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-neutral-700">Price (R) *</label>
                            <input type="number" name="price" step="0.01" id="editPrice" required class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#8da05f]">
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-neutral-700">Stock *</label>
                            <input type="number" name="stock" id="editStock" required class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#8da05f]">
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-neutral-700">Image Filename</label>
                        <input type="text" name="image" id="editImage" placeholder="default.jpg" class="w-full px-4 py-2 border border-neutral-300 rounded-lg focus:ring-2 focus:ring-[#8da05f]">
                    </div>
                </div>
                <div class="flex gap-3 mt-6">
                    <button type="button" onclick="closeModal('editModal')" class="flex-1 px-4 py-2 border border-neutral-300 rounded-lg hover:bg-neutral-50 transition">Cancel</button>
                    <button type="submit" class="flex-1 bg-[#8da05f] text-white px-4 py-2 rounded-lg hover:bg-[#75874f] transition">Save Changes</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openModal(id) {
            document.getElementById(id).classList.remove('hidden');
        }
        function closeModal(id) {
            document.getElementById(id).classList.add('hidden');
        }
        function editItem(data) {
            document.getElementById('editID').value = data.clothesID;
            document.getElementById('editName').value = data.name;
            document.getElementById('editDescription').value = data.description || '';
            document.getElementById('editPrice').value = data.price;
            document.getElementById('editStock').value = data.stock;
            document.getElementById('editImage').value = data.image || 'default.jpg';
            openModal('editModal');
        }
        // Close modal on background click
        document.querySelectorAll('.fixed.inset-0').forEach(modal => {
            modal.addEventListener('click', function(e) {
                if (e.target === this) this.classList.add('hidden');
            });
        });
    </script>

</body>
</html>