<?php
session_start();
require_once __DIR__ . '/../includes/DBConn.php';

// Check if admin is logged in
if (!isset($_SESSION['adminID']) && !isset($_SESSION['userID'])) {
    header("Location: admin_login.php");
    exit();
}

$message = '';
$error = '';

// Handle Add with file upload and duplicate check
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];
    
    if ($action === 'add') {
        $name = $conn->real_escape_string(trim($_POST['name']));
        $description = $conn->real_escape_string(trim($_POST['description']));
        $price = (float)$_POST['price'];
        $stock = (int)$_POST['stock'];
        $category = $conn->real_escape_string(trim($_POST['category'] ?? 'Uncategorized'));
        
        // Check for duplicate item (same name)
        $checkDuplicate = $conn->query("SELECT clothesID FROM tbl_Item WHERE name = '$name'");
        if ($checkDuplicate && $checkDuplicate->num_rows > 0) {
            $error = "❌ Item '$name' already exists in the database! Please use a different name.";
        } else {
            // Handle image upload
            $imageName = 'default.jpg';
            if (isset($_FILES['itemImage']) && $_FILES['itemImage']['error'] === 0) {
                $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                $ext = strtolower(pathinfo($_FILES['itemImage']['name'], PATHINFO_EXTENSION));
                if (in_array($ext, $allowed)) {
                    $imageName = time() . '_' . uniqid() . '.' . $ext;
                    $target = "../images/" . $imageName;
                    move_uploaded_file($_FILES['itemImage']['tmp_name'], $target);
                } else {
                    $error = "Invalid image format. Please use JPG, PNG, GIF, or WEBP.";
                }
            }
            
            if (empty($error)) {
                $conn->query("INSERT INTO tbl_Item (name, description, price, stock, image, category) 
                             VALUES ('$name', '$description', $price, $stock, '$imageName', '$category')");
                $conn->query("INSERT INTO tblClothes (name, description, price, stock, image, category) 
                             VALUES ('$name', '$description', $price, $stock, '$imageName', '$category')");
                
                header("Location: dashboard.php?added=1");
                exit();
            }
        }
    }
    
    if ($action === 'edit') {
        $id = (int)$_POST['clothesID'];
        $name = $conn->real_escape_string(trim($_POST['name']));
        $description = $conn->real_escape_string(trim($_POST['description']));
        $price = (float)$_POST['price'];
        $stock = (int)$_POST['stock'];
        $category = $conn->real_escape_string(trim($_POST['category'] ?? 'Uncategorized'));
        
        // Check for duplicate item (same name, different ID)
        $checkDuplicate = $conn->query("SELECT clothesID FROM tbl_Item WHERE name = '$name' AND clothesID != $id");
        if ($checkDuplicate && $checkDuplicate->num_rows > 0) {
            $error = "❌ Item '$name' already exists in the database! Please use a different name.";
        } else {
            // Handle image upload for edit
            $imageName = $_POST['current_image'] ?? 'default.jpg';
            if (isset($_FILES['editImage']) && $_FILES['editImage']['error'] === 0) {
                $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
                $ext = strtolower(pathinfo($_FILES['editImage']['name'], PATHINFO_EXTENSION));
                if (in_array($ext, $allowed)) {
                    $imageName = time() . '_' . uniqid() . '.' . $ext;
                    $target = "../images/" . $imageName;
                    move_uploaded_file($_FILES['editImage']['tmp_name'], $target);
                }
            }
            
            $conn->query("UPDATE tbl_Item SET 
                         name = '$name', description = '$description', 
                         price = $price, stock = $stock, image = '$imageName', category = '$category'
                         WHERE clothesID = $id");
            $conn->query("UPDATE tblClothes SET 
                         name = '$name', description = '$description', 
                         price = $price, stock = $stock, image = '$imageName', category = '$category'
                         WHERE clothesID = $id");
            
            header("Location: dashboard.php?edited=1");
            exit();
        }
    }
    
    if ($action === 'delete') {
        $id = (int)$_POST['clothesID'];
        $conn->query("DELETE FROM tbl_Item WHERE clothesID = $id");
        $conn->query("DELETE FROM tblClothes WHERE clothesID = $id");
        
        header("Location: dashboard.php?deleted=1");
        exit();
    }
}

// Fetch all items - DISTINCT to avoid duplicates
$items = $conn->query("SELECT DISTINCT * FROM tbl_Item ORDER BY clothesID ASC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Pastimes</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #f0ece3;
            --card: #faf8f4;
            --border: #e2ddd5;
            --text: #2c2c2c;
            --muted: #888880;
            --accent: #7a8c5c;
            --white: #ffffff;
            --red: #c0392b;
            --blue: #2980b9;
            --green: #27ae60;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'DM Sans', sans-serif;
            background: var(--bg);
            color: var(--text);
            padding: 20px;
        }
        .container { max-width: 1200px; margin: 0 auto; }
        header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 16px 0;
            border-bottom: 2px solid var(--border);
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 12px;
        }
        .logo {
            font-family: 'Playfair Display', serif;
            font-size: 24px;
            color: var(--accent);
            text-decoration: none;
        }
        .admin-actions { display: flex; gap: 12px; flex-wrap: wrap; }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-family: 'DM Sans', sans-serif;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: opacity 0.2s;
        }
        .btn:hover { opacity: 0.8; }
        .btn-primary { background: var(--accent); color: white; }
        .btn-danger { background: var(--red); color: white; }
        .btn-edit { background: var(--blue); color: white; }
        .btn-success { background: var(--green); color: white; }
        .btn-sm { padding: 6px 14px; font-size: 13px; }
        
        .table-wrap { overflow-x: auto; background: var(--white); border-radius: 12px; box-shadow: 0 2px 12px rgba(0,0,0,0.06); }
        table { width: 100%; border-collapse: collapse; }
        th { background: var(--bg); padding: 14px 16px; text-align: left; font-size: 12px; text-transform: uppercase; color: var(--muted); }
        td { padding: 12px 16px; border-bottom: 1px solid var(--border); vertical-align: middle; }
        tr:last-child td { border-bottom: none; }
        .item-img { width: 50px; height: 50px; object-fit: cover; border-radius: 6px; }
        .modal {
            display: none;
            position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.5);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }
        .modal.active { display: flex; }
        .modal-content {
            background: white;
            padding: 32px;
            border-radius: 16px;
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }
        .modal-content h2 { font-family: 'Playfair Display', serif; margin-bottom: 20px; }
        .form-group { margin-bottom: 16px; }
        .form-group label { display: block; font-size: 13px; font-weight: 600; margin-bottom: 4px; }
        .form-group input, .form-group textarea, .form-group select {
            width: 100%;
            padding: 10px 14px;
            border: 1px solid var(--border);
            border-radius: 8px;
            font-family: 'DM Sans', sans-serif;
            font-size: 14px;
        }
        .form-group textarea { resize: vertical; min-height: 60px; }
        .modal-actions { display: flex; gap: 12px; margin-top: 20px; justify-content: flex-end; }
        .toast {
            padding: 12px 20px;
            border-radius: 8px;
            color: white;
            margin-bottom: 16px;
        }
        .toast.success { background: var(--green); }
        .toast.error { background: var(--red); }
        .preview-image {
            max-width: 150px;
            max-height: 150px;
            object-fit: cover;
            border-radius: 8px;
            margin-top: 10px;
            border: 1px solid #ddd;
        }
        .file-input-wrapper {
            position: relative;
            overflow: hidden;
            display: inline-block;
            width: 100%;
        }
        .file-input-wrapper input[type=file] {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        .error-msg {
            background: #fde8e8;
            color: var(--red);
            padding: 12px 16px;
            border-radius: 8px;
            border: 1px solid #f8c4ba;
            margin-bottom: 16px;
        }
    </style>
</head>
<body>
<div class="container">
    <header>
        <a href="dashboard.php" class="logo">👑 Admin Dashboard</a>
        <div class="admin-actions">
            <button class="btn btn-primary" onclick="openModal('addModal')">+ Add New Item</button>
            <a href="manage-sellers.php" class="btn btn-primary" style="background: #d4af37; color: white;">👑 Manage Sellers</a>
            <a href="manage-listings.php" class="btn btn-primary" style="background: #e2a04f; color: white;">📦 Manage Listings</a>
            <a href="../splashPage.php" class="btn btn-primary" style="background:var(--muted);">View Site</a>
            <a href="../logout.php" class="btn btn-danger">Logout</a>
        </div>
    </header>

    <?php if (isset($_GET['added'])): ?>
    <div class="toast success">✅ Item added successfully!</div>
    <?php endif; ?>
    <?php if (isset($_GET['edited'])): ?>
    <div class="toast success">✅ Item updated successfully!</div>
    <?php endif; ?>
    <?php if (isset($_GET['deleted'])): ?>
    <div class="toast success">✅ Item deleted successfully!</div>
    <?php endif; ?>
    <?php if (isset($error)): ?>
    <div class="error-msg"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Category</th>
                    <th>Price</th>
                    <th>Stock</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($items && $items->num_rows > 0): ?>
                    <?php while ($row = $items->fetch_assoc()): ?>
                    <tr>
                        <td>#<?= $row['clothesID'] ?></td>
                        <td>
                            <img class="item-img" src="/Pastime/images/<?= htmlspecialchars($row['image'] ?? 'default.jpg') ?>" alt="">
                        </td>
                        <td><strong><?= htmlspecialchars($row['name']) ?></strong></td>
                        <td><span class="category-badge"><?= htmlspecialchars($row['category'] ?? 'Uncategorized') ?></span></td>
                        <td>R<?= number_format($row['price'], 2) ?></td>
                        <td><?= $row['stock'] ?></td>
                        <td>
                            <div style="display:flex; gap:6px; flex-wrap:wrap;">
                                <button class="btn btn-edit btn-sm" onclick="editItem(<?= $row['clothesID'] ?>)">✏️ Edit</button>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Delete this item?')">
                                    <input type="hidden" name="action" value="delete">
                                    <input type="hidden" name="clothesID" value="<?= $row['clothesID'] ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">🗑️ Delete</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="7" style="text-align:center; padding:40px; color:var(--muted);">No items found. Add your first item!</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Add Modal -->
<div class="modal" id="addModal">
    <div class="modal-content">
        <h2>➕ Add New Item</h2>
        <p class="text-sm text-neutral-500 mb-4">Check if item already exists before adding.</p>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="add">
            <div class="form-group">
                <label>Item Name *</label>
                <input type="text" name="name" required placeholder="Unique item name...">
            </div>
            <div class="form-group">
                <label>Category</label>
                <select name="category">
                    <option value="Uncategorized">Uncategorized</option>
                    <option value="Tops">Tops</option>
                    <option value="Bottoms">Bottoms</option>
                    <option value="Outerwear">Outerwear</option>
                    <option value="Footwear">Footwear</option>
                    <option value="Accessories">Accessories</option>
                </select>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea name="description"></textarea>
            </div>
            <div class="form-group">
                <label>Price (R) *</label>
                <input type="number" name="price" step="0.01" required>
            </div>
            <div class="form-group">
                <label>Stock *</label>
                <input type="number" name="stock" required>
            </div>
            <div class="form-group">
                <label>Upload Image</label>
                <div class="file-input-wrapper">
                    <button type="button" class="w-full px-4 py-2 border-2 border-dashed border-neutral-300 rounded-lg hover:border-brand-500 transition text-neutral-500 hover:text-brand-500" style="background:white;">
                        📁 Click to choose an image
                    </button>
                    <input type="file" name="itemImage" accept="image/*" id="addImageInput" onchange="validateAndPreviewAddImage(event)">
                </div>
                <div id="addImagePreviewContainer" style="display:none; margin-top:10px;">
                    <img id="addImagePreview" class="preview-image" alt="Image preview">
                    <button type="button" onclick="removeAddImage()" class="text-red-500 text-sm mt-1 hover:underline">Remove image</button>
                </div>
                <p class="text-xs text-neutral-500 mt-1">Supported formats: JPG, PNG, GIF, WEBP</p>
            </div>
            <div class="modal-actions">
                <button type="button" class="btn btn-danger" onclick="closeModal('addModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Add Item</button>
            </div>
        </form>
    </div>
</div>

<!-- Edit Modal -->
<div class="modal" id="editModal">
    <div class="modal-content">
        <h2>✏️ Edit Item</h2>
        <form method="POST" enctype="multipart/form-data" id="editForm">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="clothesID" id="editID">
            <input type="hidden" name="current_image" id="editCurrentImage">
            <div class="form-group">
                <label>Item Name *</label>
                <input type="text" name="name" id="editName" required>
            </div>
            <div class="form-group">
                <label>Category</label>
                <select name="category" id="editCategory">
                    <option value="Uncategorized">Uncategorized</option>
                    <option value="Tops">Tops</option>
                    <option value="Bottoms">Bottoms</option>
                    <option value="Outerwear">Outerwear</option>
                    <option value="Footwear">Footwear</option>
                    <option value="Accessories">Accessories</option>
                </select>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea name="description" id="editDescription"></textarea>
            </div>
            <div class="form-group">
                <label>Price (R) *</label>
                <input type="number" name="price" step="0.01" id="editPrice" required>
            </div>
            <div class="form-group">
                <label>Stock *</label>
                <input type="number" name="stock" id="editStock" required>
            </div>
            <div class="form-group">
                <label>Current Image</label>
                <img id="editCurrentImagePreview" class="preview-image" src="" alt="Current image">
            </div>
            <div class="form-group">
                <label>Upload New Image (optional)</label>
                <div class="file-input-wrapper">
                    <button type="button" class="w-full px-4 py-2 border-2 border-dashed border-neutral-300 rounded-lg hover:border-brand-500 transition text-neutral-500 hover:text-brand-500" style="background:white;">
                        📁 Click to choose a new image
                    </button>
                    <input type="file" name="editImage" accept="image/*" id="editImageInput" onchange="validateAndPreviewEditImage(event)">
                </div>
                <div id="editImagePreviewContainer" style="display:none; margin-top:10px;">
                    <img id="editImagePreview" class="preview-image" alt="New image preview">
                    <button type="button" onclick="removeEditImage()" class="text-red-500 text-sm mt-1 hover:underline">Remove new image</button>
                </div>
                <p class="text-xs text-neutral-500 mt-1">Leave empty to keep current image</p>
            </div>
            <div class="modal-actions">
                <button type="button" class="btn btn-danger" onclick="closeModal('editModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Changes</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal(id) {
    document.getElementById(id).classList.add('active');
}
function closeModal(id) {
    document.getElementById(id).classList.remove('active');
    if (id === 'addModal') {
        removeAddImage();
    }
    if (id === 'editModal') {
        removeEditImage();
    }
}

// Image validation function
function validateImage(file) {
    const allowedTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    const maxSize = 5 * 1024 * 1024; // 5MB
    
    if (!allowedTypes.includes(file.type)) {
        alert('❌ Invalid file type. Please upload JPG, PNG, GIF, or WEBP images only.');
        return false;
    }
    
    if (file.size > maxSize) {
        alert('❌ File is too large. Maximum size is 5MB.');
        return false;
    }
    
    return true;
}

// Add image preview with validation
function validateAndPreviewAddImage(event) {
    const file = event.target.files[0];
    if (file) {
        if (!validateImage(file)) {
            event.target.value = '';
            return;
        }
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('addImagePreview').src = e.target.result;
            document.getElementById('addImagePreviewContainer').style.display = 'block';
        }
        reader.readAsDataURL(file);
    }
}
function removeAddImage() {
    document.getElementById('addImageInput').value = '';
    document.getElementById('addImagePreviewContainer').style.display = 'none';
    document.getElementById('addImagePreview').src = '';
}

// Edit image preview with validation
function validateAndPreviewEditImage(event) {
    const file = event.target.files[0];
    if (file) {
        if (!validateImage(file)) {
            event.target.value = '';
            return;
        }
        const reader = new FileReader();
        reader.onload = function(e) {
            document.getElementById('editImagePreview').src = e.target.result;
            document.getElementById('editImagePreviewContainer').style.display = 'block';
        }
        reader.readAsDataURL(file);
    }
}
function removeEditImage() {
    document.getElementById('editImageInput').value = '';
    document.getElementById('editImagePreviewContainer').style.display = 'none';
    document.getElementById('editImagePreview').src = '';
}

function editItem(id) {
    fetch('get_item.php?id=' + id)
        .then(response => response.json())
        .then(data => {
            document.getElementById('editID').value = data.clothesID;
            document.getElementById('editName').value = data.name;
            document.getElementById('editDescription').value = data.description || '';
            document.getElementById('editPrice').value = data.price;
            document.getElementById('editStock').value = data.stock;
            document.getElementById('editCurrentImage').value = data.image || 'default.jpg';
            document.getElementById('editCurrentImagePreview').src = '/Pastime/images/' + (data.image || 'default.jpg');
            
            // Set category
            const catSelect = document.getElementById('editCategory');
            const catValue = data.category || 'Uncategorized';
            for (let i = 0; i < catSelect.options.length; i++) {
                if (catSelect.options[i].value === catValue) {
                    catSelect.selectedIndex = i;
                    break;
                }
            }
            
            removeEditImage();
            openModal('editModal');
        })
        .catch(() => {
            alert('Error loading item data. Please try again.');
        });
}

// Close modal on background click
document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) this.classList.remove('active');
    });
});
</script>
</body>
</html>