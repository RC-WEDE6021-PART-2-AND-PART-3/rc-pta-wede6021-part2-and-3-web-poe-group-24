<?php
session_start();
require_once __DIR__ . '/../includes/DBConn.php';

// Check admin access
if (!isset($_SESSION['adminID']) && !isset($_SESSION['userID'])) {
    die(json_encode(['error' => 'Unauthorized']));
}

if (!isset($_GET['id'])) {
    die(json_encode(['error' => 'No ID provided']));
}

$id = (int)$_GET['id'];
$result = $conn->query("SELECT * FROM tbl_Item WHERE clothesID = $id");

if ($result && $row = $result->fetch_assoc()) {
    header('Content-Type: application/json');
    echo json_encode($row);
} else {
    die(json_encode(['error' => 'Item not found']));
}
?>