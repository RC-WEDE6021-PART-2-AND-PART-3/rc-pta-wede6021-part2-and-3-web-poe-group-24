<?php
session_start();
require_once __DIR__ . '/../includes/DBConn.php';

// If already logged in as admin, redirect
if (isset($_SESSION['adminID'])) {
    header("Location: dashboard.php");
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if (empty($email) || empty($password)) {
        $error = 'Please enter both email and password.';
    } else {
        $email = $conn->real_escape_string($email);
        $password = md5($password);
        
        $result = $conn->query("SELECT * FROM tblAdmin WHERE email = '$email' AND password = '$password'");
        
        if ($result && $result->num_rows === 1) {
            $admin = $result->fetch_assoc();
            $_SESSION['adminID'] = $admin['adminID'];
            $_SESSION['adminName'] = $admin['fullName'];
            $_SESSION['role'] = 'admin';
            
            header("Location: dashboard.php");
            exit();
        } else {
            $error = 'Invalid admin credentials.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login - Pastimes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,600;1,400&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: { 50: '#f4f6f0', 500: '#8da05f', 600: '#75874f' }
                    },
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'sans-serif'],
                        serif: ['Playfair Display', 'serif']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-[#f5f0e8] min-h-screen flex items-center justify-center">
    <div class="bg-white p-8 rounded-2xl shadow-lg w-full max-w-md">
        <div class="text-center mb-8">
            <div class="text-4xl mb-2">👑</div>
            <h1 class="text-3xl font-serif text-brand-600 font-bold">Admin Portal</h1>
            <p class="text-gray-500 mt-2">Sign in to manage your store</p>
        </div>
        
        <?php if ($error): ?>
        <div class="bg-red-100 text-red-700 p-3 rounded-lg mb-4">
            <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-medium mb-2">Admin Email</label>
                <input type="email" name="email" required
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                       placeholder="admin@clothingstore.co.za">
            </div>
            
            <div class="mb-6">
                <label class="block text-gray-700 text-sm font-medium mb-2">Password</label>
                <input type="password" name="password" required
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                       placeholder="••••••••">
            </div>
            
            <button type="submit" 
                    class="w-full bg-brand-500 text-white font-medium py-2.5 rounded-lg hover:bg-brand-600 transition-colors">
                Sign In as Admin
            </button>
        </form>
        
        <p class="text-center text-sm text-gray-500 mt-4">
            <a href="../splashPage.php" class="text-brand-500 hover:underline">← Back to Store</a>
        </p>
    </div>
</body>
</html>