<?php
// Fix: Correct path to DBConn.php
require_once __DIR__ . '/includes/DBConn.php';

// Drop all tables first
$conn->query("SET FOREIGN_KEY_CHECKS = 0");
$conn->query("DROP TABLE IF EXISTS tblAorder");
$conn->query("DROP TABLE IF EXISTS tblClothes");
$conn->query("DROP TABLE IF EXISTS tblUser");
$conn->query("DROP TABLE IF EXISTS tblAdmin");
$conn->query("DROP TABLE IF EXISTS tbl_Item");
$conn->query("DROP TABLE IF EXISTS tblCart");
$conn->query("DROP TABLE IF EXISTS tblOrders");
$conn->query("DROP TABLE IF EXISTS tblOrderItems");
$conn->query("DROP TABLE IF EXISTS tblSellerRequests");
$conn->query("DROP TABLE IF EXISTS tblCommunications");
$conn->query("SET FOREIGN_KEY_CHECKS = 1");

// Create tblUser
$conn->query("
CREATE TABLE IF NOT EXISTS tblUser (
    userID     INT AUTO_INCREMENT PRIMARY KEY,
    fullName   VARCHAR(100) NOT NULL,
    email      VARCHAR(100) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,
    isVerified TINYINT(1) DEFAULT 0,
    role       ENUM('customer','seller','admin') DEFAULT 'customer',
    createdAt  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");
echo "✅ tblUser created.<br>";

// Create tblAdmin
$conn->query("
CREATE TABLE IF NOT EXISTS tblAdmin (
    adminID   INT AUTO_INCREMENT PRIMARY KEY,
    fullName  VARCHAR(100) NOT NULL,
    email     VARCHAR(100) NOT NULL UNIQUE,
    password  VARCHAR(255) NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");
echo "✅ tblAdmin created.<br>";

// Create tblClothes
$conn->query("
CREATE TABLE IF NOT EXISTS tblClothes (
    clothesID   INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    description TEXT,
    price       DECIMAL(10,2) NOT NULL,
    stock       INT DEFAULT 0,
    image       VARCHAR(100) DEFAULT 'default.jpg',
    createdAt   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");
echo "✅ tblClothes created.<br>";

// Create tbl_Item (for shop.php compatibility)
$conn->query("
CREATE TABLE IF NOT EXISTS tbl_Item (
    clothesID   INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    description TEXT,
    price       DECIMAL(10,2) NOT NULL,
    stock       INT DEFAULT 0,
    image       VARCHAR(100) DEFAULT 'default.jpg',
    createdAt   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");
echo "✅ tbl_Item created.<br>";

// Create tblAorder
$conn->query("
CREATE TABLE IF NOT EXISTS tblAorder (
    orderID   INT AUTO_INCREMENT PRIMARY KEY,
    userID    INT NOT NULL,
    clothesID INT NOT NULL,
    quantity  INT DEFAULT 1,
    orderDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userID)    REFERENCES tblUser(userID),
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID)
)");
echo "✅ tblAorder created.<br>";

// Create tblCart
$conn->query("
CREATE TABLE IF NOT EXISTS tblCart (
    cartID    INT AUTO_INCREMENT PRIMARY KEY,
    userID    INT NOT NULL,
    clothesID INT NOT NULL,
    quantity  INT DEFAULT 1,
    addedAt   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userID)    REFERENCES tblUser(userID),
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID)
)");
echo "✅ tblCart created.<br>";

// Create tblOrders
$conn->query("
CREATE TABLE IF NOT EXISTS tblOrders (
    orderID     INT AUTO_INCREMENT PRIMARY KEY,
    userID      INT NOT NULL,
    orderNumber VARCHAR(50) UNIQUE,
    totalAmount DECIMAL(10,2) NOT NULL,
    status      ENUM('Pending','Processing','Shipped','Delivered','Cancelled') DEFAULT 'Pending',
    orderDate   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userID) REFERENCES tblUser(userID)
)");
echo "✅ tblOrders created.<br>";

// Create tblOrderItems
$conn->query("
CREATE TABLE IF NOT EXISTS tblOrderItems (
    orderItemID INT AUTO_INCREMENT PRIMARY KEY,
    orderID     INT NOT NULL,
    clothesID   INT NOT NULL,
    quantity    INT NOT NULL,
    price       DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (orderID)   REFERENCES tblOrders(orderID),
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID)
)");
echo "✅ tblOrderItems created.<br>";

// Create tblSellerRequests
$conn->query("
CREATE TABLE IF NOT EXISTS tblSellerRequests (
    requestID   INT AUTO_INCREMENT PRIMARY KEY,
    userID      INT NOT NULL,
    itemName    VARCHAR(100) NOT NULL,
    description TEXT,
    itemPrice   DECIMAL(10,2) NOT NULL,
    brand       VARCHAR(50),
    image       VARCHAR(100) DEFAULT 'default.jpg',
    status      ENUM('Pending','Approved','Rejected') DEFAULT 'Pending',
    requestDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userID) REFERENCES tblUser(userID)
)");
echo "✅ tblSellerRequests created.<br>";

// Create tblCommunications
$conn->query("
CREATE TABLE IF NOT EXISTS tblCommunications (
    commID     INT AUTO_INCREMENT PRIMARY KEY,
    senderID   INT,
    receiverID INT,
    message    TEXT NOT NULL,
    isRead     TINYINT(1) DEFAULT 0,
    sentDate   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");
echo "✅ tblCommunications created.<br>";

// Insert sample admin
$adminPass = md5("admin123");
$conn->query("INSERT IGNORE INTO tblAdmin (fullName, email, password)
              VALUES ('Administrator', 'admin@clothingstore.co.za', '$adminPass')");
echo "✅ Admin account created (admin@clothingstore.co.za / admin123).<br>";

// Insert sample users
$pass = md5("password123");
$users = [
    ["John Doe",      "j.doe@abc.co.za"],
    ["Jane Smith",    "j.smith@abc.co.za"],
    ["Bob Johnson",   "b.johnson@abc.co.za"],
    ["Alice Brown",   "a.brown@abc.co.za"],
    ["Charlie Davis", "c.davis@abc.co.za"],
];
foreach ($users as $u) {
    $n = $conn->real_escape_string($u[0]);
    $e = $conn->real_escape_string($u[1]);
    $conn->query("INSERT IGNORE INTO tblUser (fullName, email, password, isVerified, role)
                  VALUES ('$n', '$e', '$pass', 1, 'customer')");
}
echo "✅ Sample users inserted.<br>";

// Insert sample clothes (both tables)
$clothes = [
    ["T-Shirt",  "Classic cotton T-Shirt - comfortable and durable",  99.99,  50, "tshirt.jpg"],
    ["Jeans",    "Slim fit denim jeans - perfect for any occasion",   299.99, 30, "jeans.jpg"],
    ["Jacket",   "Genuine leather biker jacket - timeless style",     599.99, 15, "jacket.jpg"],
    ["Sneakers", "Classic white sneakers - versatile and comfortable",399.99, 25, "sneakers.jpg"],
    ["Cap",      "Adjustable baseball cap - stylish and practical",   79.99,  60, "cap.jpg"],
];
foreach ($clothes as $c) {
    $n = $conn->real_escape_string($c[0]);
    $d = $conn->real_escape_string($c[1]);
    $img = $conn->real_escape_string($c[4]);
    
    // Insert into tblClothes
    $conn->query("INSERT IGNORE INTO tblClothes (name, description, price, stock, image)
                  VALUES ('$n', '$d', {$c[2]}, {$c[3]}, '$img')");
    
    // Insert into tbl_Item (for shop.php)
    $conn->query("INSERT IGNORE INTO tbl_Item (name, description, price, stock, image)
                  VALUES ('$n', '$d', {$c[2]}, {$c[3]}, '$img')");
}
echo "✅ Sample clothes inserted.<br>";

echo "<br><strong>✅ ClothingStore database loaded successfully!</strong>";
echo "<br><br>📋 <strong>Test Login Credentials:</strong>";
echo "<br>• Email: j.doe@abc.co.za | Password: password123";
echo "<br>• Email: j.smith@abc.co.za | Password: password123";
echo "<br>• Email: admin@clothingstore.co.za | Password: admin123";
echo "<br><br><a href='splashPage.php' style='display:inline-block;padding:12px 28px;background:#8da05f;color:white;border-radius:8px;text-decoration:none;font-weight:600;'>Go to Splash Page →</a>";
$conn->close();
?>