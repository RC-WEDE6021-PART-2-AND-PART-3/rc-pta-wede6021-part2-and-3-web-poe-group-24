<?php
session_start();
$brand = "Pastimes";
$bg = "images/PastimePlashImage.jpg";

// Check if user is logged in
$isLoggedIn = isset($_SESSION['userID']);
$userName = $isLoggedIn ? $_SESSION['fullName'] : '';

// Get the base URL dynamically
$baseURL = 'http://' . $_SERVER['HTTP_HOST'] . '/Pastime';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?=$brand?> - Pre-loved Fashion Marketplace</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,600;1,400&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { theme: { extend: { colors: { brand: { 50: '#f4f6f0', 500: '#8da05f', 600: '#75874f' }, surface: '#f5f0e8' }, fontFamily: { sans: ['Plus Jakarta Sans', 'sans-serif'], serif: ['Playfair Display', 'serif'] } } } }
    </script>
</head>
<body class="bg-surface min-h-screen flex flex-col justify-between overflow-x-hidden">

    <nav class="fixed top-0 left-0 right-0 z-50 bg-white/80 backdrop-blur-md border-b border-black/5 px-8 py-4 flex justify-between items-center transition-all">
        <a href="splashPage.php" class="text-2xl font-serif tracking-tight text-brand-600 font-bold"><?=$brand?></a>
        <div class="flex items-center gap-8 font-medium text-sm text-neutral-700">
            <!-- FIXED: Use relative path -->
            <a href="shop.php" class="hover:text-brand-500 transition-colors">Browse Marketplace</a>
            
            <?php if ($isLoggedIn): ?>
                <span class="text-brand-600">Welcome, <?= htmlspecialchars($userName) ?>!</span>
                <a href="dashboard.php" class="hover:text-brand-500 transition-colors">Dashboard</a>
                <a href="logout.php" class="text-red-500 hover:text-red-600 transition-colors">Logout</a>
            <?php else: ?>
                <a href="login.php" class="hover:text-brand-500 transition-colors">Login</a>
                <a href="register.php" class="bg-brand-500 text-white px-5 py-2.5 rounded-full hover:bg-brand-600 shadow-sm transition-all duration-300 transform hover:-translate-y-0.5">Register</a>
            <?php endif; ?>
        </div>
    </nav>

    <header class="relative min-h-screen flex items-center justify-center text-center px-4 pt-16 bg-cover bg-center" style="background-image: linear-gradient(rgba(0,0,0,0.45), rgba(0,0,0,0.55)), url('<?=$bg?>');">
        <div class="max-w-3xl space-y-6 animate-fade-in-up">
            <span class="inline-block bg-white/20 backdrop-blur-md text-white text-xs font-semibold tracking-widest uppercase px-4 py-1.5 rounded-full border border-white/20">
                Premium Thrift & Sustainable Fashion
            </span>
            <h1 class="text-5xl md:text-7xl font-serif text-white tracking-tight leading-tight">
                Buy & Sell <br><span class="italic font-normal text-brand-100">Pre-Loved</span> Masterpieces
            </h1>
            <p class="text-lg md:text-xl text-neutral-200 font-light max-w-xl mx-auto leading-relaxed">
                Our goal is to redefine secondary fashion. Pastimes connects vintage collectors and premium sellers across South Africa to create a zero-waste clothing cycle.
            </p>
            <div class="pt-4 flex flex-col sm:flex-row justify-center items-center gap-4">
                <!-- FIXED: Use relative path -->
                <a href="shop.php" class="w-full sm:w-auto bg-brand-500 text-white font-medium px-8 py-4 rounded-full shadow-lg hover:bg-brand-600 transition-all transform hover:scale-105 duration-300">
                    Explore eShop Now
                </a>
                <a href="admin/admin_login.php" class="w-full sm:w-auto bg-white/10 backdrop-blur-md text-white font-medium px-8 py-4 rounded-full border border-white/30 hover:bg-white/20 transition-all duration-300">
                    Admin Portal
                </a>
            </div>
            <?php if ($isLoggedIn): ?>
            <div class="mt-4 text-white/70 text-sm">
                👋 Welcome back, <strong><?= htmlspecialchars($userName) ?></strong>!
                <a href="dashboard.php" class="text-brand-300 hover:underline ml-2">Go to Dashboard →</a>
            </div>
            <?php endif; ?>
        </div>
    </header>

    <section class="bg-white py-16 px-8 grid grid-cols-1 md:grid-cols-3 gap-8 border-t border-neutral-100">
        <div class="text-center p-6 space-y-2">
            <div class="text-3xl text-brand-500">✨</div>
            <h3 class="text-lg font-semibold text-neutral-800">Curated Quality</h3>
            <p class="text-sm text-neutral-500">Every piece listed undergoes evaluation to protect architectural clothing standards.</p>
        </div>
        <div class="text-center p-6 space-y-2">
            <div class="text-3xl text-brand-500">🤝</div>
            <h3 class="text-lg font-semibold text-neutral-800">Verified Traders</h3>
            <p class="text-sm text-neutral-500">Our systemic admin verification step eliminates malicious actors or false items.</p>
        </div>
        <div class="text-center p-6 space-y-2">
            <div class="text-3xl text-brand-500">🇿🇦</div>
            <h3 class="text-lg font-semibold text-neutral-800">Local Exchange</h3>
            <p class="text-sm text-neutral-500">Optimized fully for local South African thrift styles and seamless fast logistics.</p>
        </div>
    </section>

</body>
</html>