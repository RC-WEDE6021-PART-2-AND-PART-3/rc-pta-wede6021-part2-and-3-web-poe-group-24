<?php
session_start();
require_once __DIR__ . '/includes/DBConn.php';

if (!isset($_SESSION['userID'])) {
    header("Location: login.php");
    exit();
}

$userID = (int)$_SESSION['userID'];

// Fetch all orders for this user
$sql = "
    SELECT o.*, 
           COUNT(oi.orderItemID) as itemCount,
           u.fullName
    FROM tblOrders o
    LEFT JOIN tblOrderItems oi ON o.orderID = oi.orderID
    LEFT JOIN tblUser u ON o.userID = u.userID
    WHERE o.userID = $userID
    GROUP BY o.orderID
    ORDER BY o.orderDate DESC
";
$orders = $conn->query($sql);

// Calculate grand total
$grandTotal = 0;
$orderData = [];
if ($orders) {
    while ($row = $orders->fetch_assoc()) {
        $orderData[] = $row;
        $grandTotal += $row['totalAmount'];
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order History - Pastimes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="bg-[#f5f0e8] min-h-screen font-sans">

    <nav class="bg-white border-b border-black/5 px-8 py-4 flex justify-between items-center">
        <a href="splashPage.php" class="text-2xl font-serif text-[#8da05f] font-bold">Pastimes</a>
        <div class="flex items-center gap-6 text-sm font-medium text-neutral-600">
            <a href="shop.php" class="hover:text-[#8da05f]">Browse</a>
            <a href="dashboard.php" class="hover:text-[#8da05f]">Dashboard</a>
            <a href="logout.php" class="text-red-500 hover:text-red-600">Logout</a>
        </div>
    </nav>

    <div class="max-w-4xl mx-auto px-6 py-10">
        <h1 class="text-3xl font-bold text-neutral-800 tracking-tight mb-2">📋 Order History</h1>
        <p class="text-sm text-neutral-500 mb-8">View all your past purchases and their details</p>

        <?php if (empty($orderData)): ?>
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-12 text-center">
                <div class="text-4xl mb-4">🛍️</div>
                <p class="text-neutral-500 text-sm">You haven't placed any orders yet.</p>
                <a href="shop.php" class="inline-block mt-4 bg-[#8da05f] text-white px-6 py-3 rounded-xl font-semibold hover:bg-[#75874f] transition">Start Shopping</a>
            </div>
        <?php else: ?>
            <div class="space-y-4">
                <?php foreach ($orderData as $row): ?>
                    <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm overflow-hidden">
                        <div class="px-6 py-4 bg-neutral-50/50 border-b border-neutral-100 flex flex-wrap items-center justify-between gap-4">
                            <div class="flex items-center gap-4">
                                <span class="font-mono font-bold text-sm"><?= htmlspecialchars($row['orderNumber']) ?></span>
                                <span class="text-xs text-neutral-500"><?= date('d M Y, H:i', strtotime($row['orderDate'])) ?></span>
                            </div>
                            <div class="flex items-center gap-3">
                                <span class="text-xs font-medium px-3 py-1 rounded-full 
                                    <?= $row['status'] === 'Delivered' ? 'bg-emerald-50 text-emerald-700' : 
                                       ($row['status'] === 'Shipped' ? 'bg-blue-50 text-blue-700' : 
                                       ($row['status'] === 'Processing' ? 'bg-amber-50 text-amber-700' : 
                                       'bg-neutral-100 text-neutral-700')) ?>">
                                    <?= htmlspecialchars($row['status']) ?>
                                </span>
                                <span class="text-sm font-bold text-[#8da05f]">R<?= number_format($row['totalAmount'], 2) ?></span>
                            </div>
                        </div>
                        <div class="px-6 py-4 text-sm text-neutral-500 flex justify-between">
                            <span><?= $row['itemCount'] ?> item(s)</span>
                            <a href="order_details.php?id=<?= $row['orderID'] ?>" class="text-[#8da05f] hover:underline">View Details →</a>
                        </div>
                    </div>
                <?php endforeach; ?>

                <!-- Grand Total -->
                <div class="bg-neutral-900 text-white rounded-2xl p-6 mt-8">
                    <div class="flex justify-between items-center">
                        <span class="text-sm font-medium text-neutral-400">📊 GRAND TOTAL OF ALL PURCHASES</span>
                        <span class="text-2xl font-bold">R<?= number_format($grandTotal, 2) ?></span>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div class="mt-6">
            <a href="dashboard.php" class="text-neutral-500 hover:text-[#8da05f] text-sm">← Back to Dashboard</a>
        </div>
    </div>
</body>
</html>