<?php
session_start();
require_once __DIR__ . '/includes/DBConn.php';

if (!isset($_SESSION['userID'])) {
    header("Location: login.php");
    exit();
}

$orderID = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$userID = (int)$_SESSION['userID'];

// Fetch order details
$stmt = $conn->prepare("
    SELECT o.*, u.fullName 
    FROM tblOrders o
    JOIN tblUser u ON o.userID = u.userID
    WHERE o.orderID = ? AND o.userID = ?
");
$stmt->bind_param("ii", $orderID, $userID);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    header("Location: order_history.php");
    exit();
}

// Fetch order items
$stmt = $conn->prepare("
    SELECT oi.*, i.name, i.image 
    FROM tblOrderItems oi
    JOIN tbl_Item i ON oi.clothesID = i.clothesID
    WHERE oi.orderID = ?
");
$stmt->bind_param("i", $orderID);
$stmt->execute();
$items = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Details - Pastimes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="bg-[#f5f0e8] min-h-screen font-sans">

    <nav class="bg-white border-b border-black/5 px-8 py-4 flex justify-between items-center">
        <a href="splashPage.php" class="text-2xl font-serif text-[#8da05f] font-bold">Pastimes</a>
        <div class="flex items-center gap-6 text-sm font-medium text-neutral-600">
            <a href="shop.php" class="hover:text-[#8da05f]">Browse</a>
            <a href="order_history.php" class="hover:text-[#8da05f]">Orders</a>
            <a href="logout.php" class="text-red-500 hover:text-red-600">Logout</a>
        </div>
    </nav>

    <div class="max-w-3xl mx-auto px-6 py-10">
        <a href="order_history.php" class="text-neutral-500 hover:text-[#8da05f] text-sm">← Back to Orders</a>

        <div class="mt-6 bg-white rounded-3xl border border-neutral-200/60 shadow-sm overflow-hidden">
            <div class="px-6 py-6 bg-neutral-50/50 border-b border-neutral-100">
                <div class="flex flex-wrap justify-between items-center gap-4">
                    <div>
                        <h1 class="text-2xl font-bold text-neutral-800">Order #<?= htmlspecialchars($order['orderNumber']) ?></h1>
                        <p class="text-sm text-neutral-500">Placed on <?= date('d M Y, H:i', strtotime($order['orderDate'])) ?></p>
                        <p class="text-sm text-neutral-500">Customer: <?= htmlspecialchars($order['fullName']) ?></p>
                    </div>
                    <span class="text-xs font-medium px-4 py-2 rounded-full 
                        <?= $order['status'] === 'Delivered' ? 'bg-emerald-50 text-emerald-700' : 
                           ($order['status'] === 'Shipped' ? 'bg-blue-50 text-blue-700' : 
                           ($order['status'] === 'Processing' ? 'bg-amber-50 text-amber-700' : 
                           'bg-neutral-100 text-neutral-700')) ?>">
                        <?= htmlspecialchars($order['status']) ?>
                    </span>
                </div>
            </div>

            <div class="p-6">
                <h2 class="font-semibold text-neutral-700 mb-4">Items</h2>
                <div class="divide-y divide-neutral-100">
                    <?php foreach ($items as $item): ?>
                    <div class="py-4 flex items-center gap-4 first:pt-0 last:pb-0">
                        <img src="/Pastime/images/<?= htmlspecialchars($item['image'] ?? 'default.jpg') ?>" 
                             alt="<?= htmlspecialchars($item['name']) ?>"
                             class="w-16 h-16 object-cover rounded-lg"
                             onerror="this.src='/Pastime/images/default.jpg'">
                        <div class="flex-1">
                            <h3 class="font-medium text-neutral-800"><?= htmlspecialchars($item['name']) ?></h3>
                            <p class="text-sm text-neutral-500">Qty: <?= $item['quantity'] ?> × R<?= number_format($item['price'], 2) ?></p>
                        </div>
                        <div class="font-semibold text-[#8da05f]">R<?= number_format($item['quantity'] * $item['price'], 2) ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>

                <div class="mt-6 pt-6 border-t border-neutral-200">
                    <div class="flex justify-between items-center">
                        <span class="text-neutral-500">Total</span>
                        <span class="text-xl font-bold text-[#8da05f]">R<?= number_format($order['totalAmount'], 2) ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>