<?php
session_start();

// Fix: Correct path to DBConn.php
require_once __DIR__ . '/includes/DBConn.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    
    if (empty($email) || empty($password)) {
        $error = 'Please enter both email and password.';
    } else {
        $email = $conn->real_escape_string($email);
        $password = md5($password); // Using MD5 as in your DBConn
        
        $result = $conn->query("SELECT * FROM tblUser WHERE email = '$email' AND password = '$password'");
        
        if ($result && $result->num_rows === 1) {
            $user = $result->fetch_assoc();
            $_SESSION['userID'] = $user['userID'];
            $_SESSION['fullName'] = $user['fullName'];
            $_SESSION['role'] = $user['role'];
            
            header("Location: /Pastime/dashboard.php");
            exit();
        } else {
            $error = 'Invalid email or password.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login - Pastimes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,600;1,400&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: { 50: '#f4f6f0', 500: '#8da05f', 600: '#75874f' }
                    },
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'sans-serif'],
                        serif: ['Playfair Display', 'serif']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-[#f5f0e8] min-h-screen flex items-center justify-center">
    <div class="bg-white p-8 rounded-2xl shadow-lg w-full max-w-md">
        <div class="text-center mb-8">
            <h1 class="text-3xl font-serif text-brand-600 font-bold">Pastimes</h1>
            <p class="text-gray-500 mt-2">Sign in to your account</p>
        </div>
        
        <?php if ($error): ?>
        <div class="bg-red-100 text-red-700 p-3 rounded-lg mb-4">
            <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>
        
        <form method="POST" action="">
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-medium mb-2">Email Address</label>
                <input type="email" name="email" required
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                       placeholder="your@email.com">
            </div>
            
            <div class="mb-6">
                <label class="block text-gray-700 text-sm font-medium mb-2">Password</label>
                <input type="password" name="password" required
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                       placeholder="••••••••">
            </div>
            
            <button type="submit" 
                    class="w-full bg-brand-500 text-white font-medium py-2.5 rounded-lg hover:bg-brand-600 transition-colors">
                Sign In
            </button>
        </form>
        
        <p class="text-center text-sm text-gray-500 mt-4">
            Don't have an account? 
            <a href="/Pastime/register.php" class="text-brand-500 hover:underline">Register here</a>
        </p>
    </div>
</body>
</html>