<?php
session_start();

// Include database connection from includes folder
require_once __DIR__ . '/includes/DBConn.php';

// Check if connection exists
if (!isset($conn) || $conn->connect_error) {
    die("Database connection failed. Please try again later.");
}

// Check if user is logged in
$isLoggedIn = isset($_SESSION['userID']);
$userID = $isLoggedIn ? (int)$_SESSION['userID'] : 0;

// Handle Add to Cart - Only if logged in
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    if (!$isLoggedIn) {
        header("Location: login.php?redirect=shop.php");
        exit();
    }
    
    $clothesID = (int)$_POST['clothesID'];
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
    
    // Check if item already in cart
    $check = $conn->query("SELECT cartID, quantity FROM tblCart WHERE userID = $userID AND clothesID = $clothesID");
    if ($check && $check->num_rows > 0) {
        $row = $check->fetch_assoc();
        $newQty = $row['quantity'] + $quantity;
        $conn->query("UPDATE tblCart SET quantity = $newQty WHERE cartID = {$row['cartID']}");
    } else {
        $conn->query("INSERT INTO tblCart (userID, clothesID, quantity) VALUES ($userID, $clothesID, $quantity)");
    }
    header("Location: shop.php?added=1");
    exit();
}

// Get cart count directly from database (only if logged in)
$cartCount = 0;
if ($isLoggedIn) {
    $cartResult = $conn->query("SELECT SUM(quantity) as total FROM tblCart WHERE userID = $userID");
    if ($cartResult) {
        $cartRow = $cartResult->fetch_assoc();
        $cartCount = (int)($cartRow['total'] ?? 0);
    }
}

// Get category filter from URL
$categoryFilter = isset($_GET['category']) ? $conn->real_escape_string(trim($_GET['category'])) : '';
$categorySQL = $categoryFilter ? "AND category = '$categoryFilter'" : '';

// Single item view
$viewItem = null;
if (isset($_GET['item'])) {
    $id = (int)$_GET['item'];
    $res = $conn->query("SELECT * FROM tbl_Item WHERE clothesID = $id");
    if ($res && $res->num_rows > 0) {
        $viewItem = $res->fetch_assoc();
    } else {
        header("Location: shop.php");
        exit();
    }
}

// Search
$search = isset($_GET['search']) ? $conn->real_escape_string(trim($_GET['search'])) : '';
$searchSQL = $search ? "AND (name LIKE '%$search%' OR description LIKE '%$search%')" : '';

// FIXED: Group by name to eliminate duplicates, keeping the lowest clothesID
$result = $conn->query("
    SELECT MIN(clothesID) as clothesID, 
           name, 
           description, 
           price, 
           MIN(stock) as stock, 
           image, 
           category
    FROM tbl_Item 
    WHERE 1=1 $categorySQL $searchSQL 
    GROUP BY name 
    ORDER BY clothesID ASC
");

$clothes = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $clothes[] = $row;
    }
}

// Get all unique categories for filter dropdown
$categories = [];
$catResult = $conn->query("SELECT DISTINCT category FROM tbl_Item WHERE category IS NOT NULL AND category != '' ORDER BY category");
if ($catResult) {
    while ($row = $catResult->fetch_assoc()) {
        $categories[] = $row['category'];
    }
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= $viewItem ? htmlspecialchars($viewItem['name']) : 'Browse' ?> - Pastimes</title>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg:     #f0ece3;
            --card:   #faf8f4;
            --border: #e2ddd5;
            --text:   #2c2c2c;
            --muted:  #888880;
            --accent: #7a8c5c;
            --white:  #ffffff;
            --red:    #c0392b;
            --green:  #27ae60;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'DM Sans', sans-serif;
            background: var(--bg);
            color: var(--text);
            min-height: 100vh;
        }

        /* HEADER */
        header {
            background: var(--bg);
            border-bottom: 1px solid var(--border);
            padding: 0 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            height: 56px;
            position: sticky;
            top: 0;
            z-index: 100;
        }
        .logo {
            font-family: 'Playfair Display', serif;
            font-size: 20px;
            color: var(--accent);
            text-decoration: none;
        }
        nav { display: flex; align-items: center; gap: 20px; }
        nav a {
            color: var(--text); text-decoration: none;
            font-size: 14px; transition: color 0.2s;
        }
        nav a:hover { color: var(--accent); }
        .nav-cart { position: relative; font-size: 18px; }
        .cart-badge {
            position: absolute; top: -6px; right: -8px;
            background: var(--accent); color: white;
            border-radius: 50%; width: 16px; height: 16px;
            font-size: 10px; display: flex;
            align-items: center; justify-content: center; font-weight: 600;
        }
        .btn-register {
            background: var(--accent); color: white !important;
            padding: 8px 20px; border-radius: 6px; font-size: 14px;
        }
        .btn-register:hover { background: #627048 !important; }

        /* LOGGED IN BAR */
        .logged-bar {
            background: var(--accent); color: white;
            padding: 8px 40px; font-size: 13px; font-weight: 500;
        }

        /* Toast Message */
        .toast {
            max-width: 960px;
            margin: 16px auto 0;
            padding: 0 20px;
        }
        .toast-inner {
            background: #d4edda;
            color: #155724;
            padding: 12px 20px;
            border-radius: 8px;
            border: 1px solid #c3e6cb;
            font-weight: 500;
        }

        /* SEARCH BAR */
        .search-wrap {
            max-width: 960px;
            margin: 30px auto 24px;
            padding: 0 20px;
        }
        .search-box {
            display: flex;
            align-items: center;
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: 8px;
            padding: 12px 18px;
            gap: 12px;
        }
        .search-icon { color: var(--muted); font-size: 16px; }
        .search-input {
            border: none; outline: none; font-size: 15px;
            font-family: 'DM Sans', sans-serif;
            color: var(--text); background: transparent; width: 100%;
        }
        .search-input::placeholder { color: var(--muted); }

        /* CATEGORY FILTER BAR */
        .category-bar {
            max-width: 960px;
            margin: 0 auto 24px;
            padding: 0 20px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        .category-btn {
            padding: 8px 20px;
            border-radius: 50px;
            border: 1px solid var(--border);
            background: var(--white);
            color: var(--text);
            font-size: 13px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.2s;
            font-family: 'DM Sans', sans-serif;
            text-decoration: none;
        }
        .category-btn:hover {
            border-color: var(--accent);
            background: var(--bg);
        }
        .category-btn.active {
            background: var(--accent);
            color: white;
            border-color: var(--accent);
        }
        .category-btn.active:hover {
            background: #627048;
        }

        /* MAIN LAYOUT */
        .browse-layout {
            max-width: 960px;
            margin: 0 auto;
            padding: 0 20px 60px;
            display: grid;
            grid-template-columns: 200px 1fr;
            gap: 30px;
            align-items: start;
        }

        /* FILTERS SIDEBAR */
        .filters { display: flex; flex-direction: column; gap: 20px; }
        .filters-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 4px;
        }
        .filters-title { font-size: 16px; font-weight: 600; }
        .clear-all {
            font-size: 13px; color: var(--muted);
            text-decoration: none; cursor: pointer;
            background: none; border: none;
            font-family: 'DM Sans', sans-serif;
            transition: color 0.2s;
        }
        .clear-all:hover { color: var(--accent); }

        .filter-group { display: flex; flex-direction: column; gap: 8px; }
        .filter-label {
            font-size: 13px; font-weight: 500; color: var(--text);
        }
        .filter-select {
            padding: 9px 12px;
            border: 1px solid var(--border);
            border-radius: 6px;
            font-size: 13px;
            font-family: 'DM Sans', sans-serif;
            background: var(--white);
            color: var(--text);
            outline: none;
            cursor: pointer;
        }
        .filter-select:focus { border-color: var(--accent); }

        .price-range {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 8px;
        }
        .price-input {
            padding: 9px 12px;
            border: 1px solid var(--border);
            border-radius: 6px;
            font-size: 13px;
            font-family: 'DM Sans', sans-serif;
            background: var(--white);
            color: var(--text);
            outline: none;
            width: 100%;
        }
        .price-input::placeholder { color: var(--muted); }
        .price-input:focus { border-color: var(--accent); }

        .condition-input {
            padding: 9px 12px;
            border: 1px solid var(--border);
            border-radius: 6px;
            font-size: 13px;
            font-family: 'DM Sans', sans-serif;
            background: var(--white);
            color: var(--text);
            outline: none;
            width: 100%;
        }

        /* ITEMS AREA */
        .items-area {}

        .items-count {
            font-size: 14px; color: var(--muted);
            margin-bottom: 20px;
        }

        .items-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        /* ITEM CARD */
        .item-card {
            background: var(--white);
            border-radius: 8px;
            overflow: hidden;
            cursor: pointer;
            text-decoration: none;
            color: var(--text);
            display: block;
            transition: transform 0.2s, box-shadow 0.2s;
            position: relative;
        }
        .item-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 24px rgba(0,0,0,0.1);
        }
        .item-img-wrap { position: relative; overflow: hidden; }
        .item-card img {
            width: 100%; height: 280px;
            object-fit: cover; display: block;
            transition: transform 0.3s;
        }
        .item-card:hover img { transform: scale(1.03); }

        /* Heart button */
        .heart-btn {
            position: absolute; top: 12px; right: 12px;
            width: 34px; height: 34px;
            background: white; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 16px; cursor: pointer;
            border: none; box-shadow: 0 2px 8px rgba(0,0,0,0.12);
            color: var(--muted); transition: color 0.2s, transform 0.2s;
            z-index: 2;
        }
        .heart-btn:hover { color: #c0392b; transform: scale(1.1); }
        .heart-btn.liked  { color: #c0392b; }

        .item-card-body { padding: 14px 16px 16px; }
        .item-card-brand {
            font-size: 11px; color: var(--muted);
            text-transform: uppercase; letter-spacing: 0.6px;
            margin-bottom: 4px;
        }
        .item-card-name {
            font-family: 'Playfair Display', serif;
            font-size: 16px; font-weight: 600;
            margin-bottom: 8px; line-height: 1.3;
        }
        .item-card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .item-card-price {
            font-size: 15px; font-weight: 500; color: var(--text);
        }
        .item-card-condition {
            font-size: 12px; color: var(--muted);
        }

        /* Add to Cart button on card */
        .card-add-btn {
            display: block;
            width: 100%;
            padding: 10px;
            margin-top: 12px;
            background: var(--accent);
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
            font-family: 'DM Sans', sans-serif;
            transition: background 0.2s;
        }
        .card-add-btn:hover { background: #627048; }
        .card-add-btn:disabled {
            background: var(--muted);
            cursor: not-allowed;
        }

        /* Category Badge on item card */
        .category-badge {
            display: inline-block;
            font-size: 9px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 2px 10px;
            border-radius: 50px;
            background: var(--bg);
            color: var(--muted);
            margin-top: 4px;
        }

        /* NO RESULTS */
        .no-results {
            grid-column: 1 / -1;
            text-align: center; padding: 60px 20px;
            color: var(--muted); font-size: 15px;
        }

        /* DETAIL VIEW */
        .detail-container {
            max-width: 960px;
            margin: 40px auto;
            padding: 0 20px;
        }
        .back-link {
            display: inline-block; color: var(--muted); font-size: 13px;
            text-decoration: none; margin-bottom: 30px; transition: color 0.2s;
        }
        .back-link:hover { color: var(--accent); }
        .detail-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 50px; align-items: start;
        }
        .detail-img {
            width: 100%; border-radius: 10px;
            object-fit: cover; max-height: 520px;
        }
        .detail-info { display: flex; flex-direction: column; gap: 16px; }
        .detail-category {
            font-size: 13px; color: var(--muted);
            text-transform: uppercase; letter-spacing: 0.5px;
        }
        .detail-name {
            font-family: 'Playfair Display', serif;
            font-size: 32px; font-weight: 700;
            line-height: 1.2;
        }
        .detail-price-row { display: flex; align-items: center; gap: 16px; }
        .detail-price { font-size: 24px; font-weight: 600; }
        .condition-badge {
            background: #eaf2e3; color: #4a7c2f;
            padding: 4px 12px; border-radius: 20px; font-size: 12px;
        }
        .detail-divider { border: none; border-top: 1px solid var(--border); }
        .detail-label {
            font-size: 12px; color: var(--muted);
            text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;
        }
        .detail-value { font-size: 15px; }
        .seller-row {
            display: flex; align-items: center; gap: 12px;
            padding: 14px 0;
            border-top: 1px solid var(--border);
            border-bottom: 1px solid var(--border);
        }
        .seller-avatar {
            width: 42px; height: 42px; border-radius: 50%;
            background: var(--accent);
            display: flex; align-items: center; justify-content: center;
            font-family: 'Playfair Display', serif;
            font-size: 18px; color: white;
        }
        .seller-name  { font-size: 14px; font-weight: 500; }
        .seller-rating{ font-size: 12px; color: var(--muted); margin-top: 2px; }
        .btn-addcart {
            width: 100%; padding: 16px;
            background: var(--accent); color: white;
            border: none; border-radius: 6px;
            font-size: 15px; font-weight: 500; cursor: pointer;
            font-family: 'DM Sans', sans-serif; transition: background 0.2s;
        }
        .btn-addcart:hover { background: #627048; }
        .btn-addcart:disabled {
            background: var(--muted);
            cursor: not-allowed;
        }
        .offer-row { display: flex; gap: 10px; }
        .offer-input {
            flex: 1; padding: 12px 16px;
            border: 1px solid var(--border); border-radius: 6px;
            font-size: 14px; background: var(--white);
            font-family: 'DM Sans', sans-serif; color: var(--muted); outline: none;
        }
        .offer-input:focus { border-color: var(--accent); }
        .btn-offer {
            padding: 12px 20px;
            border: 1px solid var(--border); border-radius: 6px;
            background: var(--white); color: var(--text);
            font-size: 14px; cursor: pointer;
            font-family: 'DM Sans', sans-serif; transition: border-color 0.2s;
        }
        .btn-offer:hover { border-color: var(--accent); color: var(--accent); }
        .btn-wishlist {
            width: 100%; padding: 14px;
            border: 1px solid #e8b4b4; border-radius: 6px;
            background: #fff8f8; color: #c0392b;
            font-size: 14px; cursor: pointer;
            font-family: 'DM Sans', sans-serif; transition: background 0.2s;
        }
        .btn-wishlist:hover { background: #ffe8e8; }
        .description-title { font-size: 15px; font-weight: 600; margin-bottom: 8px; }
        .description-text  { font-size: 14px; color: var(--muted); line-height: 1.7; }

        /* POPUP */
        .popup-overlay {
            display: none; position: fixed;
            top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.4);
            justify-content: center; align-items: center; z-index: 1000;
        }
        .popup-overlay.active { display: flex; }
        .popup {
            background: var(--white); border-radius: 12px;
            padding: 40px; width: 360px; text-align: center;
            box-shadow: 0 10px 40px rgba(0,0,0,0.15);
            animation: popIn 0.25s ease;
        }
        @keyframes popIn {
            from { transform: scale(0.9); opacity: 0; }
            to   { transform: scale(1);   opacity: 1; }
        }
        .popup-img {
            width: 110px; height: 110px; object-fit: cover;
            border-radius: 8px; margin-bottom: 16px;
            border: 1px solid var(--border);
        }
        .popup-name  {
            font-family: 'Playfair Display', serif;
            font-size: 20px; margin-bottom: 8px;
        }
        .popup-price {
            font-size: 30px; font-weight: 700;
            color: var(--accent); margin: 12px 0;
        }
        .popup-desc  { font-size: 13px; color: var(--muted); margin-bottom: 24px; }
        .popup-btns  { display: flex; gap: 10px; }
        .popup-confirm {
            flex: 1; padding: 12px;
            background: var(--accent); color: white;
            border: none; border-radius: 6px; font-size: 14px; cursor: pointer;
            font-family: 'DM Sans', sans-serif;
        }
        .popup-confirm:hover { background: #627048; }
        .popup-cancel {
            flex: 1; padding: 12px;
            background: #fde8e8; color: #c0392b;
            border: none; border-radius: 6px; font-size: 14px; cursor: pointer;
            font-family: 'DM Sans', sans-serif;
        }
        .popup-cancel:hover { background: #fbd0d0; }

        /* FOOTER */
        footer {
            background: var(--card);
            border-top: 1px solid var(--border);
            padding: 40px; margin-top: 40px;
        }
        .footer-grid {
            max-width: 960px; margin: 0 auto;
            display: grid;
            grid-template-columns: 2fr 1fr 1fr; gap: 40px;
        }
        .footer-brand .logo { font-size: 18px; display: block; margin-bottom: 10px; }
        .footer-brand p { font-size: 13px; color: var(--muted); line-height: 1.6; }
        .footer-col h4 {
            font-size: 12px; font-weight: 600; color: var(--text);
            margin-bottom: 14px; text-transform: uppercase; letter-spacing: 0.5px;
        }
        .footer-col a {
            display: block; font-size: 13px; color: var(--muted);
            text-decoration: none; margin-bottom: 8px; transition: color 0.2s;
        }
        .footer-col a:hover { color: var(--accent); }

        /* Responsive */
        @media (max-width: 768px) {
            .browse-layout {
                grid-template-columns: 1fr;
            }
            .items-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            .detail-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            .category-bar {
                gap: 6px;
            }
            .category-btn {
                font-size: 11px;
                padding: 6px 14px;
            }
        }
        @media (max-width: 480px) {
            .items-grid {
                grid-template-columns: 1fr;
            }
            header {
                padding: 0 16px;
            }
            nav {
                gap: 10px;
            }
        }
    </style>
</head>
<body>

<!-- Header -->
<header>
    <a href="dashboard.php" class="logo">Pastimes</a>
    <nav>
        <a href="shop.php">Browse</a>
        <?php if ($isLoggedIn): ?>
        <a href="dashboard.php">Dashboard</a>
        <a href="cart.php" class="nav-cart" style="font-size:18px;">
            🛒
            <?php if ($cartCount > 0): ?>
                <span class="cart-badge"><?= $cartCount ?></span>
            <?php endif; ?>
        </a>
        <a href="logout.php" style="color:var(--muted);">Logout</a>
        <?php else: ?>
        <a href="login.php" style="color:var(--accent);font-weight:600;">Login</a>
        <a href="register.php" class="btn-register">Register</a>
        <?php endif; ?>
    </nav>
</header>

<!-- Logged in bar -->
<?php if ($isLoggedIn): ?>
<div class="logged-bar" id="loggedBar">
    User <?= htmlspecialchars($_SESSION['fullName'] ?? 'User') ?> is logged in
</div>
<?php else: ?>
<div class="logged-bar" style="background:var(--muted);">
    👋 Welcome! <a href="login.php" style="color:white;font-weight:600;">Sign in</a> or <a href="register.php" style="color:white;font-weight:600;">Register</a> to start shopping
</div>
<?php endif; ?>

<!-- Toast Message -->
<?php if (isset($_GET['added'])): ?>
<div class="toast">
    <div class="toast-inner">✅ Item added to cart successfully!</div>
</div>
<?php endif; ?>

<?php if ($viewItem): ?>
<!-- ── DETAIL VIEW ── -->
<div class="detail-container">
    <a href="shop.php" class="back-link">← Back to Browse</a>
    <div class="detail-grid">
        <div>
            <img class="detail-img"
                 src="images/<?= htmlspecialchars($viewItem['image'] ?? 'default.jpg') ?>"
                 alt="<?= htmlspecialchars($viewItem['name']) ?>"
                 onerror="this.src='images/default.jpg'">
        </div>
        <div class="detail-info">
            <div class="detail-category"><?= htmlspecialchars($viewItem['category'] ?? 'Uncategorized') ?></div>
            <div class="detail-name"><?= htmlspecialchars($viewItem['name']) ?></div>
            <div class="detail-price-row">
                <div class="detail-price">R<?= number_format($viewItem['price'], 2) ?></div>
                <span class="condition-badge">
                    <?= $viewItem['stock'] > 0 ? 'In Stock' : 'Out of Stock' ?>
                </span>
            </div>
            <hr class="detail-divider">
            <div>
                <div class="detail-label">Stock Available</div>
                <div class="detail-value"><?= $viewItem['stock'] ?> units</div>
            </div>
            <div class="seller-row">
                <div class="seller-avatar">C</div>
                <div>
                    <div class="seller-name">clothingstore_official</div>
                    <div class="seller-rating">⭐ 5.0 (verified seller)</div>
                </div>
            </div>
            <?php if ($isLoggedIn): ?>
            <form method="POST" action="">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="clothesID" value="<?= $viewItem['clothesID'] ?>">
                <button type="submit" class="btn-addcart" <?= $viewItem['stock'] <= 0 ? 'disabled' : '' ?>>
                    <?= $viewItem['stock'] > 0 ? '🛒 Add to Cart' : 'Out of Stock' ?>
                </button>
            </form>
            <?php else: ?>
            <div class="p-4 bg-amber-50 border border-amber-200 rounded-lg text-center">
                <p class="text-amber-700 text-sm">Please <a href="login.php?redirect=shop.php" class="font-bold underline">Login</a> or <a href="register.php" class="font-bold underline">Register</a> to add items to cart</p>
            </div>
            <?php endif; ?>
            <div class="offer-row">
                <input type="text" class="offer-input" placeholder="Make an offer">
                <button class="btn-offer">Send Offer</button>
            </div>
            <button class="btn-wishlist">♥ Remove from Wishlist</button>
            <div>
                <div class="description-title">Description</div>
                <div class="description-text"><?= htmlspecialchars($viewItem['description'] ?? 'No description available.') ?></div>
            </div>
        </div>
    </div>
</div>

<?php else: ?>
<!-- ── BROWSE VIEW ── -->

<!-- Search -->
<div class="search-wrap">
    <form method="GET" action="shop.php">
        <?php if ($categoryFilter): ?>
        <input type="hidden" name="category" value="<?= htmlspecialchars($categoryFilter) ?>">
        <?php endif; ?>
        <div class="search-box">
            <span class="search-icon">🔍</span>
            <input type="text" name="search" class="search-input"
                   placeholder="Search for items..."
                   value="<?= htmlspecialchars($search) ?>">
        </div>
    </form>
</div>

<!-- Category Filter Bar -->
<div class="category-bar">
    <a href="shop.php" class="category-btn <?= !$categoryFilter ? 'active' : '' ?>">All</a>
    <?php foreach ($categories as $cat): ?>
    <a href="shop.php?category=<?= urlencode($cat) ?>" 
       class="category-btn <?= $categoryFilter === $cat ? 'active' : '' ?>">
        <?= htmlspecialchars($cat) ?>
    </a>
    <?php endforeach; ?>
</div>

<!-- Browse Layout -->
<div class="browse-layout">

    <!-- Filters -->
    <aside class="filters">
        <div class="filters-header">
            <div class="filters-title">Filters</div>
            <a href="shop.php" class="clear-all">Clear All</a>
        </div>

        <div class="filter-group">
            <div class="filter-label">Category</div>
            <select class="filter-select" onchange="window.location.href=this.value">
                <option value="shop.php">All Categories</option>
                <?php foreach ($categories as $cat): ?>
                <option value="shop.php?category=<?= urlencode($cat) ?>" <?= $categoryFilter === $cat ? 'selected' : '' ?>>
                    <?= htmlspecialchars($cat) ?>
                </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="filter-group">
            <div class="filter-label">Price Range (R)</div>
            <div class="price-range">
                <input type="number" class="price-input" id="minPrice"
                       placeholder="Min" onkeyup="filterItems()">
                <input type="number" class="price-input" id="maxPrice"
                       placeholder="Max" onkeyup="filterItems()">
            </div>
        </div>

        <div class="filter-group">
            <div class="filter-label">Min Condition</div>
            <input type="text" class="condition-input"
                   placeholder="1-10" id="conditionFilter" onkeyup="filterItems()">
        </div>
    </aside>

    <!-- Items -->
    <div class="items-area">
        <div class="items-count" id="itemsCount">
            <?= count($clothes) ?> unique item<?= count($clothes) !== 1 ? 's' : '' ?> found
            <?php if ($categoryFilter): ?>
            in <strong><?= htmlspecialchars($categoryFilter) ?></strong>
            <?php endif; ?>
        </div>

        <div class="items-grid" id="itemsGrid">
            <?php if (count($clothes) > 0): ?>
                <?php foreach ($clothes as $item): ?>
                <div class="item-card" data-price="<?= $item['price'] ?>">
                    <a href="shop.php?item=<?= $item['clothesID'] ?>">
                        <div class="item-img-wrap">
                            <img src="images/<?= htmlspecialchars($item['image'] ?? 'default.jpg') ?>"
                                 alt="<?= htmlspecialchars($item['name']) ?>"
                                 onerror="this.src='images/default.jpg'">
                            <button class="heart-btn"
                                    onclick="toggleHeart(event, this)">♡</button>
                        </div>
                    </a>
                    <div class="item-card-body">
                        <a href="shop.php?item=<?= $item['clothesID'] ?>" style="text-decoration:none;color:inherit;">
                            <div class="item-card-brand"><?= htmlspecialchars($item['category'] ?? 'Uncategorized') ?></div>
                            <div class="item-card-name"><?= htmlspecialchars($item['name']) ?></div>
                        </a>
                        <div class="item-card-footer">
                            <div class="item-card-price">R<?= number_format($item['price'], 2) ?></div>
                            <div class="item-card-condition">
                                <?= $item['stock'] > 20 ? 'Excellent' : ($item['stock'] > 0 ? 'Good' : 'Out of Stock') ?>
                            </div>
                        </div>
                        <?php if ($isLoggedIn): ?>
                        <form method="POST" action="">
                            <input type="hidden" name="action" value="add">
                            <input type="hidden" name="clothesID" value="<?= $item['clothesID'] ?>">
                            <button type="submit" class="card-add-btn" <?= $item['stock'] <= 0 ? 'disabled' : '' ?>>
                                🛒 <?= $item['stock'] > 0 ? 'Add to Cart' : 'Out of Stock' ?>
                            </button>
                        </form>
                        <?php else: ?>
                        <a href="login.php?redirect=shop.php" class="card-add-btn" style="display:block;text-align:center;background:var(--muted);text-decoration:none;font-size:12px;">
                            🔒 Login to Add to Cart
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="no-results">No items found matching your search.</div>
            <?php endif; ?>
        </div>
    </div>

</div>
<?php endif; ?>

<!-- Footer -->
<footer>
    <div class="footer-grid">
        <div class="footer-brand">
            <a href="dashboard.php" class="logo">Pastimes</a>
            <p>Buy and sell pre-loved fashion with confidence.</p>
        </div>
        <div class="footer-col">
            <h4>Company</h4>
            <a href="#">About</a>
            <a href="#">Contact</a>
            <a href="#">Terms and Conditions</a>
        </div>
        <div class="footer-col">
            <h4>Support</h4>
            <a href="#">Help Center</a>
            <a href="#">Shipping Info</a>
            <a href="#">Returns</a>
        </div>
    </div>
</footer>

<script>
    // Hide logged in bar
    setTimeout(function() {
        var bar = document.getElementById('loggedBar');
        if (!bar) return;
        bar.style.transition = 'opacity 0.5s ease';
        bar.style.opacity = '0';
        setTimeout(function() { bar.style.display = 'none'; }, 500);
    }, 1000);

    // Heart toggle
    function toggleHeart(e, btn) {
        e.preventDefault();
        e.stopPropagation();
        btn.classList.toggle('liked');
        btn.innerHTML = btn.classList.contains('liked') ? '♥' : '♡';
    }

    // Price filter
    function filterItems() {
        var min   = parseFloat(document.getElementById('minPrice')?.value) || 0;
        var max   = parseFloat(document.getElementById('maxPrice')?.value) || Infinity;
        var cards = document.querySelectorAll('.item-card');
        var count = 0;
        cards.forEach(function(card) {
            var price = parseFloat(card.dataset.price);
            if (price >= min && price <= max) {
                card.style.display = 'block';
                count++;
            } else {
                card.style.display = 'none';
            }
        });
        var countEl = document.getElementById('itemsCount');
        if (countEl) {
            var text = count + ' unique item' + (count !== 1 ? 's' : '') + ' found';
            <?php if ($categoryFilter): ?>
            text += ' in <strong><?= htmlspecialchars($categoryFilter) ?></strong>';
            <?php endif; ?>
            countEl.innerHTML = text;
        }
    }
</script>
</body>
</html>