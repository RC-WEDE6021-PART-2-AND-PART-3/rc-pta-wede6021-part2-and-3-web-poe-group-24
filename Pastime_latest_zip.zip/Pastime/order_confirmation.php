<?php
session_start();
require_once __DIR__ . '/includes/DBConn.php';

if (!isset($_SESSION['userID'])) {
    header("Location: login.php");
    exit();
}

if (!isset($_SESSION['last_order'])) {
    header("Location: shop.php");
    exit();
}

$order = $_SESSION['last_order'];
$orderNumber = $order['orderNumber'];
$total = $order['totalAmount'];
$orderID = $order['orderID'];

// Get order details
$stmt = $conn->prepare("
    SELECT oi.*, i.name, i.image 
    FROM tblOrderItems oi
    JOIN tbl_Item i ON oi.clothesID = i.clothesID
    WHERE oi.orderID = ?
");
$stmt->bind_param("i", $orderID);
$stmt->execute();
$orderItems = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Clear the stored order so it doesn't show again on refresh
unset($_SESSION['last_order']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Confirmation - Pastimes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .fade-in { animation: fadeIn 0.6s ease-out; }
    </style>
</head>
<body class="bg-[#f5f0e8] min-h-screen font-sans">

    <nav class="bg-white border-b border-black/5 px-8 py-4 flex justify-between items-center">
        <a href="splashPage.php" class="text-2xl font-serif text-[#8da05f] font-bold">Pastimes</a>
        <div class="flex items-center gap-6 text-sm font-medium text-neutral-600">
            <a href="shop.php" class="hover:text-[#8da05f]">Continue Shopping</a>
            <a href="dashboard.php" class="hover:text-[#8da05f]">Dashboard</a>
            <a href="logout.php" class="text-red-500 hover:text-red-600">Logout</a>
        </div>
    </nav>

    <div class="max-w-2xl mx-auto px-6 py-12 fade-in">
        <div class="bg-white rounded-3xl shadow-xl p-8 border border-neutral-100 text-center">
            <div class="text-6xl mb-4">✅</div>
            <h1 class="text-3xl font-bold text-neutral-800 tracking-tight">Order Placed!</h1>
            <p class="text-neutral-500 mt-2">Thank you for shopping at Pastimes. Your order has been confirmed.</p>

            <!-- Order Number -->
            <div class="mt-6 bg-neutral-50 rounded-2xl p-6 border border-neutral-100">
                <p class="text-sm text-neutral-500">Order Number</p>
                <p class="font-mono font-bold text-2xl text-[#8da05f]"><?= htmlspecialchars($orderNumber) ?></p>
                <p class="text-xs text-neutral-400 mt-1">Session ID: <?= session_id() ?></p>
            </div>

            <!-- Order Items -->
            <div class="mt-6 text-left">
                <h3 class="font-semibold text-neutral-700 mb-3">Order Items</h3>
                <div class="space-y-2">
                    <?php foreach ($orderItems as $item): ?>
                    <div class="flex items-center gap-4 bg-neutral-50 p-3 rounded-lg">
                        <img src="/Pastime/images/<?= htmlspecialchars($item['image'] ?? 'default.jpg') ?>" 
                             alt="<?= htmlspecialchars($item['name']) ?>"
                             class="w-12 h-12 object-cover rounded"
                             onerror="this.src='/Pastime/images/default.jpg'">
                        <div class="flex-1">
                            <p class="font-medium text-sm"><?= htmlspecialchars($item['name']) ?></p>
                            <p class="text-xs text-neutral-500">Qty: <?= $item['quantity'] ?> × R<?= number_format($item['price'], 2) ?></p>
                        </div>
                        <div class="font-semibold text-[#8da05f]">R<?= number_format($item['quantity'] * $item['price'], 2) ?></div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Total -->
            <div class="mt-6 bg-neutral-900 text-white rounded-2xl p-6">
                <div class="flex justify-between items-center">
                    <span class="text-sm font-medium text-neutral-400">TOTAL</span>
                    <span class="text-2xl font-bold">R<?= number_format($total, 2) ?></span>
                </div>
            </div>

            <div class="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
                <a href="shop.php" class="bg-[#8da05f] text-white px-8 py-3 rounded-xl font-semibold hover:bg-[#75874f] transition">
                    🛍️ Continue Shopping
                </a>
                <a href="order_history.php" class="bg-neutral-100 text-neutral-700 px-8 py-3 rounded-xl font-semibold hover:bg-neutral-200 transition">
                    📋 View Orders
                </a>
            </div>
        </div>
    </div>
</body>
</html>