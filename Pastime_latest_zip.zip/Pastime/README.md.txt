# Pastimes - Pre-loved Fashion Marketplace

## Project Overview
Pastimes is a web-based e-commerce platform for buying and selling pre-loved fashion items. Users can browse items, add to cart, checkout, and track their order history.

## Technologies Used
- PHP 8.2
- MySQL
- HTML/CSS (Tailwind CSS)
- JavaScript

## Features Implemented
1. User Registration and Login
2. Shopping Cart with Add, Remove, Update
3. Checkout with Order Number Generation
4. Order History with Grand Total
5. Admin Dashboard with CRUD Operations
6. Category Filtering and Search
7. Image Upload for Items
8. Seller Application and Management

## Installation Instructions
1. Copy files to htdocs/Pastime/
2. Import ClothingStore.sql to phpMyAdmin
3. Update includes/DBConn.php with your database credentials

## Test Credentials
- Admin: admin@clothingstore.co.za / admin123
- User: j.doe@abc.co.za / password123

## Video Demo Link
[Link to your video]