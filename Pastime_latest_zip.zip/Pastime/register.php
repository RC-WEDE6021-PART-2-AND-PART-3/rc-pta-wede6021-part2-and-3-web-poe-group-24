<?php
session_start();

// Fix: Correct path to DBConn.php
require_once __DIR__ . '/includes/DBConn.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullName = trim($_POST['fullName'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $confirmPassword = trim($_POST['confirmPassword'] ?? '');
    
    if (empty($fullName) || empty($email) || empty($password)) {
        $error = 'Please fill in all required fields.';
    } elseif ($password !== $confirmPassword) {
        $error = 'Passwords do not match.';
    } elseif (strlen($password) < 6) {
        $error = 'Password must be at least 6 characters.';
    } else {
        $fullName = $conn->real_escape_string($fullName);
        $email = $conn->real_escape_string($email);
        $password = md5($password);
        
        // Check if email already exists
        $check = $conn->query("SELECT userID FROM tblUser WHERE email = '$email'");
        if ($check && $check->num_rows > 0) {
            $error = 'Email already registered. Please login.';
        } else {
            $conn->query("INSERT INTO tblUser (fullName, email, password, isVerified) 
                         VALUES ('$fullName', '$email', '$password', 1)");
            
            if ($conn->affected_rows > 0) {
                $success = 'Registration successful! You can now login.';
            } else {
                $error = 'Registration failed. Please try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - Pastimes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,600;1,400&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: { 50: '#f4f6f0', 500: '#8da05f', 600: '#75874f' }
                    },
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'sans-serif'],
                        serif: ['Playfair Display', 'serif']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-[#f5f0e8] min-h-screen flex items-center justify-center">
    <div class="bg-white p-8 rounded-2xl shadow-lg w-full max-w-md">
        <div class="text-center mb-8">
            <h1 class="text-3xl font-serif text-brand-600 font-bold">Pastimes</h1>
            <p class="text-gray-500 mt-2">Create your account</p>
        </div>
        
        <?php if ($error): ?>
        <div class="bg-red-100 text-red-700 p-3 rounded-lg mb-4">
            <?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
        <div class="bg-green-100 text-green-700 p-3 rounded-lg mb-4">
            <?= htmlspecialchars($success) ?>
        </div>
        <?php endif; ?>
        
        <?php if (!$success): ?>
        <form method="POST" action="">
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-medium mb-2">Full Name</label>
                <input type="text" name="fullName" required
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                       placeholder="John Doe">
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-medium mb-2">Email Address</label>
                <input type="email" name="email" required
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                       placeholder="your@email.com">
            </div>
            
            <div class="mb-4">
                <label class="block text-gray-700 text-sm font-medium mb-2">Password</label>
                <input type="password" name="password" required minlength="6"
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                       placeholder="Min 6 characters">
            </div>
            
            <div class="mb-6">
                <label class="block text-gray-700 text-sm font-medium mb-2">Confirm Password</label>
                <input type="password" name="confirmPassword" required
                       class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                       placeholder="Confirm your password">
            </div>
            
            <button type="submit" 
                    class="w-full bg-brand-500 text-white font-medium py-2.5 rounded-lg hover:bg-brand-600 transition-colors">
                Create Account
            </button>
        </form>
        <?php endif; ?>
        
        <p class="text-center text-sm text-gray-500 mt-4">
            Already have an account? 
            <a href="/Pastime/login.php" class="text-brand-500 hover:underline">Sign in here</a>
        </p>
    </div>
</body>
</html>