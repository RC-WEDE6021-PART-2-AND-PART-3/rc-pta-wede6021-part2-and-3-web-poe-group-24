<?php
require __DIR__ . "/includes/DBConn.php";

// Disable foreign key checks so we can drop tables freely
$conn->query("SET FOREIGN_KEY_CHECKS = 0");
echo "Foreign key checks disabled.<br>";

// Drop tblAorder first (it depends on tblUser)
$conn->query("DROP TABLE IF EXISTS tblAorder");
echo "tblAorder dropped.<br>";

// Now drop tblUser
$conn->query("DROP TABLE IF EXISTS tblUser");
echo "tblUser dropped.<br>";

// Re-enable foreign key checks
$conn->query("SET FOREIGN_KEY_CHECKS = 1");
echo "Foreign key checks re-enabled.<br><br>";

// Recreate tblUser
$createSQL = "
CREATE TABLE tblUser (
    userID     INT AUTO_INCREMENT PRIMARY KEY,
    fullName   VARCHAR(100) NOT NULL,
    email      VARCHAR(100) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,
    isVerified TINYINT(1) DEFAULT 0,
    role       VARCHAR(20) DEFAULT 'customer',
    createdAt  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";

if ($conn->query($createSQL)) {
    echo "tblUser recreated successfully.<br>";
} else {
    die("Error creating table: " . $conn->error);
}

// Recreate tblAorder
$createOrder = "
CREATE TABLE tblAorder (
    orderID   INT AUTO_INCREMENT PRIMARY KEY,
    userID    INT NOT NULL,
    clothesID INT NOT NULL,
    quantity  INT DEFAULT 1,
    orderDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userID)    REFERENCES tblUser(userID),
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID)
)";

if ($conn->query($createOrder)) {
    echo "tblAorder recreated successfully.<br><br>";
} else {
    echo "Error recreating tblAorder: " . $conn->error . "<br><br>";
}

// Load data from userData.txt
$file = fopen("userData.txt", "r");
if (!$file) {
    die("Cannot open userData.txt — make sure it exists in the same folder.");
}

$count = 0;
while (($line = fgets($file)) !== false) {
    $line = trim($line);
    if (empty($line)) continue;

    $parts = explode("\t", $line);
    if (count($parts) < 3) continue;

    $fullName = $conn->real_escape_string(trim($parts[0]));
    $email    = $conn->real_escape_string(trim($parts[1]));
    $hash     = $conn->real_escape_string(trim($parts[2]));

    $sql = "INSERT INTO tblUser (fullName, email, password, isVerified)
            VALUES ('$fullName', '$email', '$hash', 1)";

    if ($conn->query($sql)) {
        echo "Inserted: $fullName<br>";
        $count++;
    } else {
        echo "Error inserting $fullName: " . $conn->error . "<br>";
    }
}
fclose($file);

echo "<br><strong>✅ Done! tblUser has been reset and $count records loaded from userData.txt.</strong>";
echo "<br><br><a href='index.php'>Go to Login Page</a>";

$conn->close();
?>