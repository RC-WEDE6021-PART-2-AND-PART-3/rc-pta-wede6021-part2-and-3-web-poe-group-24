<?php
session_start();
require_once __DIR__ . '/includes/DBConn.php';

// Protect page access
if (!isset($_SESSION['userID'])) {
    header("Location: splashPage.php");
    exit();
}

$userID = $_SESSION['userID'];
$role = $_SESSION['role'] ?? 'customer';
$fullName = $_SESSION['fullName'] ?? 'User';

// Get user data
$stmt = $conn->prepare("SELECT * FROM tblUser WHERE userID = ?");
$stmt->bind_param("i", $userID);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Fallbacks
$fullName = $user['fullName'] ?? $fullName;
$email = $user['email'] ?? '';
$createdAt = $user['createdAt'] ?? 'now';
$firstLetter = strtoupper(substr(trim($fullName), 0, 1));
$firstName = explode(' ', trim($fullName))[0];

// Get cart count directly from database
$cartCount = 0;
$cartResult = $conn->query("SELECT SUM(quantity) as total FROM tblCart WHERE userID = $userID");
if ($cartResult) {
    $cartRow = $cartResult->fetch_assoc();
    $cartCount = (int)($cartRow['total'] ?? 0);
}

// Get order count - using tblOrders (not tbl_Orders)
$orderResult = $conn->query("SELECT COUNT(*) as count FROM tblOrders WHERE userID = $userID");
$orderCount = $orderResult ? (int)$orderResult->fetch_assoc()['count'] : 0;

$wishlistCount = 0; // Placeholder
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Pastimes</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700&family=Playfair+Display:ital,wght@0,600;1,400&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        brand: { 50: '#f4f6f0', 500: '#8da05f', 600: '#75874f' }
                    },
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'sans-serif'],
                        serif: ['Playfair Display', 'serif']
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-[#f5f0e8] min-h-screen font-sans">

    <nav class="bg-white border-b border-black/5 px-8 py-4 flex justify-between items-center">
        <a href="splashPage.php" class="text-2xl font-serif text-brand-600 font-bold">Pastimes</a>
        <div class="flex items-center gap-6 text-sm font-medium text-neutral-600">
            <a href="shop.php" class="hover:text-brand-500">Browse</a>
            <a href="cart.php" class="hover:text-brand-500 relative">
                🛒 Cart
                <?php if ($cartCount > 0): ?>
                    <span class="absolute -top-1 -right-4 bg-brand-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center"><?= $cartCount ?></span>
                <?php endif; ?>
            </a>
            <?php if ($role === 'admin' || $role === 'superadmin'): ?>
                <a href="admin_dashboard.php" class="text-amber-600 hover:text-amber-700 font-bold">👑 Admin</a>
            <?php endif; ?>
            <a href="logout.php" class="text-red-500 hover:text-red-600">Logout</a>
        </div>
    </nav>

    <div class="max-w-6xl mx-auto px-6 py-10">
        
        <!-- Welcome Card -->
        <div class="bg-white rounded-3xl border border-neutral-200/60 shadow-sm p-8 mb-8">
            <div class="flex items-center gap-4">
                <div class="w-16 h-16 rounded-full bg-brand-500 text-white flex items-center justify-center text-2xl font-bold font-serif">
                    <?= htmlspecialchars($firstLetter) ?>
                </div>
                <div>
                    <h1 class="text-2xl font-bold text-neutral-800">Welcome back, <?= htmlspecialchars($firstName) ?>! 👋</h1>
                    <p class="text-sm text-neutral-500">Email: <?= htmlspecialchars($email) ?></p>
                    <p class="text-sm text-neutral-500">Member since <?= date('d M Y', strtotime($createdAt)) ?></p>
                </div>
            </div>
        </div>

        <!-- Stats -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-6 text-center">
                <div class="text-3xl mb-1">🛍️</div>
                <div class="text-2xl font-bold text-brand-600"><?= $orderCount ?></div>
                <div class="text-sm text-neutral-500">Orders</div>
            </div>
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-6 text-center">
                <div class="text-3xl mb-1">🛒</div>
                <div class="text-2xl font-bold text-brand-600"><?= $cartCount ?></div>
                <div class="text-sm text-neutral-500">Cart Items</div>
            </div>
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-6 text-center">
                <div class="text-3xl mb-1">❤️</div>
                <div class="text-2xl font-bold text-brand-600"><?= $wishlistCount ?></div>
                <div class="text-sm text-neutral-500">Wishlist</div>
            </div>
            <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-6 text-center">
                <div class="text-3xl mb-1">⭐</div>
                <div class="text-2xl font-bold text-brand-600"><?= htmlspecialchars(ucfirst($role)) ?></div>
                <div class="text-sm text-neutral-500">Role</div>
            </div>
        </div>

	<!-- Seller Section -->
<?php 
$userCheck = $conn->query("SELECT is_seller, seller_status FROM tblUser WHERE userID = $userID")->fetch_assoc();
if ($userCheck && $userCheck['is_seller'] == 1): 
?>
<div class="mt-8">
    <div class="flex justify-between items-center mb-4">
        <h2 class="font-semibold text-neutral-700">👑 Seller Mode</h2>
        <?php if ($userCheck['seller_status'] === 'approved'): ?>
        <a href="/Pastime/seller/dashboard.php" class="text-brand-600 hover:underline text-sm">Go to Seller Dashboard →</a>
        <?php endif; ?>
    </div>
    
    <?php if ($userCheck['seller_status'] === 'pending'): ?>
    <div class="bg-amber-50 border border-amber-200 rounded-2xl p-6">
        <p class="text-amber-800">⏳ Your seller application is pending admin approval.</p>
        <p class="text-sm text-amber-600 mt-1">You'll be notified when your application is reviewed.</p>
    </div>
    <?php elseif ($userCheck['seller_status'] === 'approved'): ?>
    <div class="bg-green-50 border border-green-200 rounded-2xl p-6">
        <p class="text-green-800">✅ Your seller account is active!</p>
        <p class="text-sm text-green-600 mt-1">You can now list items and manage your store.</p>
        <a href="/Pastime/seller/dashboard.php" class="inline-block mt-3 bg-brand-500 text-white px-6 py-2 rounded-xl hover:bg-brand-600 transition text-sm">
            Go to Seller Dashboard →
        </a>
    </div>
    <?php elseif ($userCheck['seller_status'] === 'rejected'): ?>
    <div class="bg-red-50 border border-red-200 rounded-2xl p-6">
        <p class="text-red-800">❌ Your seller application was rejected.</p>
        <p class="text-sm text-red-600 mt-1">Please contact support for more information.</p>
    </div>
    <?php endif; ?>
</div>
<?php else: ?>
<div class="mt-8">
    <div class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-6 flex flex-wrap justify-between items-center gap-4">
        <div>
            <h3 class="font-semibold text-neutral-800">👑 Want to become a seller?</h3>
            <p class="text-sm text-neutral-500">Start selling your items on Pastimes</p>
        </div>
        <a href="/Pastime/seller/apply.php" class="bg-brand-500 text-white px-6 py-2 rounded-xl hover:bg-brand-600 transition">
            Apply to Sell
        </a>
    </div>
</div>
<?php endif; ?>

        <!-- Quick Actions -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <a href="shop.php" class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-6 hover:shadow-md transition text-center">
                <div class="text-4xl mb-2">🛍️</div>
                <h3 class="font-semibold text-neutral-800">Continue Shopping</h3>
                <p class="text-sm text-neutral-500">Browse our collection</p>
            </a>
            <a href="cart.php" class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-6 hover:shadow-md transition text-center">
                <div class="text-4xl mb-2">🛒</div>
                <h3 class="font-semibold text-neutral-800">View Cart</h3>
                <p class="text-sm text-neutral-500"><?= $cartCount ?> items in your cart</p>
            </a>
            <a href="order_history.php" class="bg-white rounded-2xl border border-neutral-200/60 shadow-sm p-6 hover:shadow-md transition text-center">
                <div class="text-4xl mb-2">📋</div>
                <h3 class="font-semibold text-neutral-800">Order History</h3>
                <p class="text-sm text-neutral-500">View past orders</p>
            </a>
        </div>

        <?php if ($role === 'admin' || $role === 'superadmin'): ?>
        <!-- Admin Quick Actions -->
        <div class="mt-8">
            <h2 class="font-semibold text-neutral-700 mb-4">👑 Admin Quick Actions</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <a href="admin_dashboard.php" class="bg-amber-50 border border-amber-200 rounded-2xl p-6 hover:shadow-md transition text-center">
                    <div class="text-3xl mb-2">📦</div>
                    <h3 class="font-semibold text-amber-800">Manage Items</h3>
                    <p class="text-sm text-amber-600">Add, edit, delete products</p>
                </a>
                <a href="admin_communications.php" class="bg-amber-50 border border-amber-200 rounded-2xl p-6 hover:shadow-md transition text-center">
                    <div class="text-3xl mb-2">💬</div>
                    <h3 class="font-semibold text-amber-800">Communications</h3>
                    <p class="text-sm text-amber-600">View user messages</p>
                </a>
                <a href="admin_clothes.php" class="bg-amber-50 border border-amber-200 rounded-2xl p-6 hover:shadow-md transition text-center">
                    <div class="text-3xl mb-2">👕</div>
                    <h3 class="font-semibold text-amber-800">Clothes Management</h3>
                    <p class="text-sm text-amber-600">Detailed item management</p>
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>

</body>
</html>