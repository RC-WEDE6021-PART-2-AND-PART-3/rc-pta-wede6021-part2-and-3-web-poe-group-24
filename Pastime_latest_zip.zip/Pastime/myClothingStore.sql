-- --------------------------------------------------------
-- ClothingStore Database - Complete Schema
-- --------------------------------------------------------

DROP DATABASE IF EXISTS ClothingStore;
CREATE DATABASE ClothingStore;
USE ClothingStore;

SET FOREIGN_KEY_CHECKS = 0;

-- ============================================
-- TABLE: tblAdmin
-- ============================================
DROP TABLE IF EXISTS tblAdmin;
CREATE TABLE tblAdmin (
    adminID   INT AUTO_INCREMENT PRIMARY KEY,
    fullName  VARCHAR(100) NOT NULL,
    email     VARCHAR(100) NOT NULL UNIQUE,
    password  VARCHAR(255) NOT NULL,
    createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO tblAdmin (fullName, email, password) VALUES
('Administrator', 'admin@clothingstore.co.za', MD5('admin123'));

-- ============================================
-- TABLE: tblUser
-- ============================================
DROP TABLE IF EXISTS tblUser;
CREATE TABLE tblUser (
    userID     INT AUTO_INCREMENT PRIMARY KEY,
    fullName   VARCHAR(100) NOT NULL,
    email      VARCHAR(100) NOT NULL UNIQUE,
    password   VARCHAR(255) NOT NULL,
    isVerified TINYINT(1) DEFAULT 0,
    role       ENUM('customer','seller','admin') DEFAULT 'customer',
    createdAt  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO tblUser (fullName, email, password, isVerified, role) VALUES
('John Doe',          'j.doe@abc.co.za',          MD5('password123'), 1, 'customer'),
('Jane Smith',        'j.smith@abc.co.za',        MD5('password123'), 1, 'customer'),
('Bob Johnson',       'b.johnson@abc.co.za',      MD5('password123'), 1, 'seller'),
('Alice Brown',       'a.brown@abc.co.za',        MD5('password123'), 1, 'customer'),
('Charlie Davis',     'c.davis@abc.co.za',        MD5('password123'), 1, 'seller');

-- ============================================
-- TABLE: tblClothes
-- ============================================
DROP TABLE IF EXISTS tblClothes;
CREATE TABLE tblClothes (
    clothesID   INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    description TEXT,
    price       DECIMAL(10,2) NOT NULL,
    stock       INT DEFAULT 0,
    image       VARCHAR(100) DEFAULT 'default.jpg',
    createdAt   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO tblClothes (name, description, price, stock, image) VALUES
('T-Shirt',  'Classic cotton T-Shirt',                 99.99,  50, 'tshirt.jpg'),
('Jeans',    'Slim fit denim jeans',                   299.99, 30, 'jeans.jpg'),
('Jacket',   'Genuine leather biker jacket',           599.99, 15, 'jacket.jpg'),
('Sneakers', 'Classic white sneakers',                 399.99, 25, 'sneakers.jpg'),
('Cap',      'Adjustable baseball cap',                79.99,  60, 'cap.jpg');

-- ============================================
-- TABLE: tbl_Item (shop.php compatibility)
-- ============================================
DROP TABLE IF EXISTS tbl_Item;
CREATE TABLE tbl_Item (
    clothesID   INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    description TEXT,
    price       DECIMAL(10,2) NOT NULL,
    stock       INT DEFAULT 0,
    image       VARCHAR(100) DEFAULT 'default.jpg',
    createdAt   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO tbl_Item (clothesID, name, description, price, stock, image) VALUES
(1, 'T-Shirt',  'Classic cotton T-Shirt',                 99.99,  50, 'tshirt.jpg'),
(2, 'Jeans',    'Slim fit denim jeans',                   299.99, 30, 'jeans.jpg'),
(3, 'Jacket',   'Genuine leather biker jacket',           599.99, 15, 'jacket.jpg'),
(4, 'Sneakers', 'Classic white sneakers',                 399.99, 25, 'sneakers.jpg'),
(5, 'Cap',      'Adjustable baseball cap',                79.99,  60, 'cap.jpg');

-- ============================================
-- TABLE: tblAorder (Legacy)
-- ============================================
DROP TABLE IF EXISTS tblAorder;
CREATE TABLE tblAorder (
    orderID   INT AUTO_INCREMENT PRIMARY KEY,
    userID    INT NOT NULL,
    clothesID INT NOT NULL,
    quantity  INT DEFAULT 1,
    orderDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userID)    REFERENCES tblUser(userID),
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID)
);

-- ============================================
-- TABLE: tblCart
-- ============================================
DROP TABLE IF EXISTS tblCart;
CREATE TABLE tblCart (
    cartID    INT AUTO_INCREMENT PRIMARY KEY,
    userID    INT NOT NULL,
    clothesID INT NOT NULL,
    quantity  INT DEFAULT 1,
    addedAt   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userID)    REFERENCES tblUser(userID),
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID)
);

-- ============================================
-- TABLE: tblOrders
-- ============================================
DROP TABLE IF EXISTS tblOrders;
CREATE TABLE tblOrders (
    orderID     INT AUTO_INCREMENT PRIMARY KEY,
    userID      INT NOT NULL,
    orderNumber VARCHAR(50) UNIQUE,
    totalAmount DECIMAL(10,2) NOT NULL,
    status      ENUM('Pending','Processing','Shipped','Delivered','Cancelled') DEFAULT 'Pending',
    orderDate   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userID) REFERENCES tblUser(userID)
);

-- ============================================
-- TABLE: tblOrderItems
-- ============================================
DROP TABLE IF EXISTS tblOrderItems;
CREATE TABLE tblOrderItems (
    orderItemID INT AUTO_INCREMENT PRIMARY KEY,
    orderID     INT NOT NULL,
    clothesID   INT NOT NULL,
    quantity    INT NOT NULL,
    price       DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (orderID)   REFERENCES tblOrders(orderID),
    FOREIGN KEY (clothesID) REFERENCES tblClothes(clothesID)
);

-- ============================================
-- TABLE: tblSellerRequests
-- ============================================
DROP TABLE IF EXISTS tblSellerRequests;
CREATE TABLE tblSellerRequests (
    requestID   INT AUTO_INCREMENT PRIMARY KEY,
    userID      INT NOT NULL,
    itemName    VARCHAR(100) NOT NULL,
    description TEXT,
    itemPrice   DECIMAL(10,2) NOT NULL,
    brand       VARCHAR(50),
    image       VARCHAR(100) DEFAULT 'default.jpg',
    status      ENUM('Pending','Approved','Rejected') DEFAULT 'Pending',
    requestDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userID) REFERENCES tblUser(userID)
);

-- ============================================
-- TABLE: tblCommunications
-- ============================================
DROP TABLE IF EXISTS tblCommunications;
CREATE TABLE tblCommunications (
    commID     INT AUTO_INCREMENT PRIMARY KEY,
    senderID   INT,
    receiverID INT,
    message    TEXT NOT NULL,
    isRead     TINYINT(1) DEFAULT 0,
    sentDate   TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

SET FOREIGN_KEY_CHECKS = 1;